<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['opentok_key'] = '45790432'; //45764262
$config['opentok_secret'] = 'c4b9fa3a72d4d9413b7b8a4045e385db5fda65ba';
