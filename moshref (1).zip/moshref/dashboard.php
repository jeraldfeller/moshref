
<!DOCTYPE html>
<html lang="en" class="clickfunnels-com wf-proximanova-i3-active wf-proximanova-i4-active wf-proximanova-i7-active wf-proximanova-n3-active wf-proximanova-n4-active wf-proximanova-n7-active wf-active elFont_driodserif wf-proximanovasoft-n4-active wf-proximanovasoft-n7-active elFont_opensans" style='overflow: initial; font-family: "Open Sans", Helvetica, sans-serif !important; background-color: rgb(234, 234, 234);'>
<head data-next-url="" data-this-url="https://captainmoneypants.com/membership-area/abff71bae4c?webinar_ext=T2JM7RhM">
  <meta charset="UTF-8">
  <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
  <meta content="utf-8" http-equiv="encoding">
  <meta name="viewport" content="initial-scale=1">
    <title>The Moneypants Solution Digital Online Course</title>
<meta class="metaTagTop" name="description" content="">
<meta class="metaTagTop" name="keywords" content="">
<meta class="metaTagTop" name="author" content="">
<meta class="metaTagTop" property="og:image" content="" id="social-image">
    <meta property="og:title" content="The Moneypants Solution Digital Online Course">
<meta property="og:description" content="">
  <meta property="og:url" content="https://captainmoneypants.com/membership-area/abff71bae4c">
  <meta property="og:type" content="website">

  <link rel="stylesheet" media="screen" href="https://appassets.clickfunnels.com/assets/lander.css">

  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7COswald:400,700%7CDroid+Sans:400,700%7CRoboto:400,700%7CLato:400,700%7CPT+Sans:400,700%7CSource+Sans+Pro:400,700%7CNoto+Sans:400,700%7CPT+Sans:400,700%7CUbuntu:400,700%7CBitter:400,700%7CPT+Serif:400,700%7CRokkitt:400,700%7CDroid+Serif:400,700%7CRaleway:400,700%7CInconsolata:400,700" rel="stylesheet" type="text/css">

    <meta property="cf:funnel_id" content="bU5MR01EUDBYM21YT3paSTZUTHJIQT09LS1wUTI4cFhhUjR0OXpGaTdidWpqU0tRPT0=--e755503834453ecdc59e718ec587f93dfa61fc7f">
    <meta property="cf:page_id" content="b1FSZ3VrZXFMeWtCYkFsSzBRSzMxdz09LS1Kb094OWNuNW8vdlBlc21yT0ZXN29BPT0=--1dc1728869ce61f6f4c03fd0dd045c57339f82cc">
    <meta property="cf:funnel_step_id" content="cFVQbGg0RmxIMWxkUDY5OFphMWJuQT09LS1sRU8vUlA4YTIwWTVZQnF6QWdFSlRnPT0=--44d1b4c804613018d1c2d4b495e076b067826e21">
    <meta property="cf:user_id" content="K25hZ244Qmt6N1Y5b0F4TmYvSlVLUT09LS1KOGxMVUZnWmsxTzU5WHlZTlRJbnlnPT0=--401455d4ab2f8f13fc7ffd8259bce1de4c54dfdd">
    <meta property="cf:page_code" content="OTIyODEzOA==">
    <meta property="cf:mode_id" content="1">
    <meta property="cf:time_zone" content="UTC">

    <script src="https://appassets.clickfunnels.com/assets/userevents/application.js"></script>


  <script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');ga('create','UA-51074959-1','auto',{'name':'cftracker'});ga('cftracker.send','pageview','user-page');</script>
  <style>
    [data-timed-style='fade']{display:none}[data-timed-style='scale']{display:none}
  </style>
<link rel='icon' type='image/png' href=''></link><!-- Hotjar Tracking Code for http://www.captainmoneypants.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:255137,hjsv:5};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
</script>
</head>
  <body data-affiliate-param="affiliate_id">
<svg xmlns="http://www.w3.org/2000/svg" style="display: none !important">
  <filter id="grayscale">
    <fecolormatrix type="matrix" values="0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"></fecolormatrix>
  </filter>
</svg>
  <div class="containerWrapper">
    <input id="submit-form-action" value="redirect-url" data-url="#" data-ar-service="" data-ar-list="" data-webhook="" type="hidden"> <div class="nodoHiddenFormFields hide"> <input id="elHidden1" class="elInputHidden elInput" name="ad" type="hidden"> <input id="elHidden2" class="elInputHidden elInput" name="tag" type="hidden"> <input id="elHidden3" class="elInputHidden elInput" name="" type="hidden"> <input id="elHidden4" class="elInputHidden elInput" name="" type="hidden"> <input id="elHidden5" class="elInputHidden elInput" name="" type="hidden"> </div> <div class="nodoCustomHTML hide"></div> <div class="modalBackdropWrapper" style="display: none; background-color: rgba(0, 0, 0, 0.4);"></div> <div class="container containerModal midContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px cornersAll radius10 shadow0 bgNoRepeat emptySection modalMoveOver" id="modalPopup" data-title="Modal" data-block-color="0074C7" style="display: none; margin-top: 100px; padding-top: 40px; padding-bottom: 40px; outline: none; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="top" data-delay="0"> <div class="containerInner ui-sortable"></div> <div class="closeLPModal"><img src="https://nodo.s3.amazonaws.com/editor/closemodal.png" alt=""></div>
</div>
<div class="container noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px activeSection_topBorder0 activeSection_bottomBorder0 emptySection activeSection_topBorder activeSection_bottomBorder bgCover100 wideContainer cornersAll radius0 shadow0 nosticky" id="section-7428910000" data-title="header" data-block-color="0074C7" style="padding-top: 10px; padding-bottom: 10px; outline: none; margin-top: 0px; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500">
<div class="containerInner ui-sortable" style="padding-left: 20px; padding-right: 20px;">
<div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin innerToolsTop" id="row-4628510000" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left Sidebar row" style="outline: none; margin-bottom: 0px;">
<div id="col-left-761" class="col-md-4 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="left column" style="outline: none;">
<div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin">
<div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-73702" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;" data-imagelink="http://www.captainmoneypants.com">
<img src="https://images.clickfunnels.com/61/f146402ded11e6af2bbf000e8a207f/Moneypants-Logo-B-20160510.png" class="elIMG ximg" data-imagelink="http://www.captainmoneypants.com">
</div>
</div>
</div>
<div id="col-right-187" class="col-md-8 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="right column" style="outline: none;">
<div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin">
<div class="de elHeadlineWrapper de-editable" id="tmp_headline1-67102" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 40px; cursor: pointer; outline: none;">
<div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: right; font-size: 16px;" data-bold="inherit" contenteditable="false"><b>
<a href="/members/sign_out" id="link-4013-277" class="" target="_self" style="color: rgb(0, 0, 0);">Logout</a></b></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="container wideContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection" id="section--33288" data-title="Section" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 0px; outline: none; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500">
<div class="containerInner ui-sortable">
<div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70597" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding: 0px 10px;">
<div id="col-full-144" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;">
<div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin">
<div class="de elSeperator elMargin0 de-editable" id="tmp_divider-89772" data-de-type="divider" data-de-editing="false" data-title="Divider" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;">
<div class="elDivider elDividerStyle2 elDividerColor3">
<div class="elDividerInner"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="container noTopMargin padding40-top padding40-bottom padding40H  borderSolid border3px bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 radius5 emptySection activeSection_topBorder activeSection_bottomBorder noBorder cornersBottom shadow0 wideContainer" id="section-6721910000" data-title="members area" data-block-color="0074C7" style="padding-top: 20px; padding-bottom: 40px; outline: none; margin-top: 0px; border-color: rgba(47, 47, 47, 0.2); background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500">
<div class="containerInner ui-sortable">
<div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-5801810000" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left Sidebar row" style="outline: none; margin-bottom: 0px;" col-array="3,9">
<div id="col-left-685" class="innerContent col_left ui-resizable col-md-3" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="left column" style="outline: none;">
<div class="col-inner bgCover  borderSolid cornersAll shadow0 P0-top P0-bottom P0H noTopMargin border1px radius10 borderLight block_floatnone block_positionnone" style="padding-bottom: 30px; padding-left: 10px; padding-right: 10px; border-color: rgb(204, 204, 204); background-color: rgb(230, 230, 230);">
<div class="de clearfix elMembershipsNav elButtonNoShadow membershipNavGrey elMargin0 de-editable" id="tmp_membernavi-34678" data-de-type="membernavi" data-de-editing="false" data-title="Membership Nav 2.0" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style='margin-top: 10px; display: block; cursor: pointer; outline: none; font-family: "Open Sans", Helvetica, sans-serif !important;' data-google-font="Open+Sans">
<ul class="steps">
<li data-cf-section-template="true" data-target=".section1" data-toggle="collapse" class="membershipNavTitle">
<div class="title opened elButtonNoShadow" style="background-color: rgb(110, 117, 127);">
<strong data-cf-section-name="true">Moneypants Setup Videos</strong>
</div>
</li>
<li data-cf-lesson-list="true" class="step1 collapse in membershipNavInner elButtonNoShadow section1">
<div data-cf-lesson-template="true">
<ul>
<li>
<a href="#" class="lesson-link" id="1-1">
<span data-cf-lesson-name="true">Introduction (Start Here)</span>
</a>
<span data-cf-lesson-video="true" class="lesson-video hide"></span>
<textarea class="hide" data-cf-lesson-description="true">&lt;style id="button_style_tmp_button-23022"&gt;#tmp_button-23022 .elButtonFlat:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonBottomBorder:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonSubtle:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(25,56,71)),color-stop(1,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:linear-gradient(to bottom,rgb(25,56,71) 0%,#0e2029 100%);}#tmp_button-23022 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(25,56,71)),color-stop(0,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:linear-gradient(to bottom,rgb(25,56,71) 100%,#0e2029 0%);}#tmp_button-23022 .elButtonBorder{border:3px solid rgb(25,56,71)!important;color:rgb(25,56,71)!important;}#tmp_button-23022 .elButtonBorder:hover{background-color:rgb(25,56,71)!important;color:#FFF!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 border2px radius5 emptySection noBorder" id="section-4218110000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.0666667); margin-top: 0px; background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  borderSolid cornersAll shadow0 P0-top P0-bottom P0H noTopMargin block_positionnone radius10 borderLight border1px" id="row-5760410000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding: 10px 0px; margin-left: 150px; margin-right: 150px; border-color: rgb(204, 204, 204); background-color: rgb(153, 153, 153);"&gt;
&lt;div id="col-full-742" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-58132" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize2" style="text-align: center; font-size: 36px; color: rgb(255, 255, 255);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;Introduction&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="headline-59304" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; outline: none; margin-top: 0px; display: block;"&gt;
&lt;div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize0" style="text-align: center; color: rgb(255, 255, 255); font-size: 24px;" data-bold="inherit" contenteditable="false"&gt;The Moneypants Solution&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border2px noBorder" id="section-7360810000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 10px; outline: none; border-color: rgba(47, 47, 47, 0.219608); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-8320210000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-995" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="tmp_video-39579" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169805431" data-hide-on="all" data-vimeo-autoplay="yes"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169805431?autoplay=1&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
</textarea>
</li>
</ul>
</div>
<div data-cf-lesson-template="true">
<ul>
<li>
<a href="#" class="lesson-link" id="temp-link">
<span data-cf-lesson-name="true">
Lesson Auto Updated
</span>
</a>
<span data-cf-lesson-video="true" class="lesson-video hide">VIDEO EMBED HERE</span>
<textarea class="hide" data-cf-lesson-description="true">Short lesson description can go here.</textarea>
</li>
</ul>
</div>
<div data-cf-lesson-template="true">
<ul>
<li>
<a href="#" class="lesson-link" id="1-2">
<span data-cf-lesson-name="true">Step #1: Pants That Fit</span>
</a>
<span data-cf-lesson-video="true" class="lesson-video hide"></span>
<textarea class="hide" data-cf-lesson-description="true">&lt;style id="button_style_tmp_button-23022"&gt;#tmp_button-23022 .elButtonFlat:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonBottomBorder:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonSubtle:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(25,56,71)),color-stop(1,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:linear-gradient(to bottom,rgb(25,56,71) 0%,#0e2029 100%);}#tmp_button-23022 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(25,56,71)),color-stop(0,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:linear-gradient(to bottom,rgb(25,56,71) 100%,#0e2029 0%);}#tmp_button-23022 .elButtonBorder{border:3px solid rgb(25,56,71)!important;color:rgb(25,56,71)!important;}#tmp_button-23022 .elButtonBorder:hover{background-color:rgb(25,56,71)!important;color:#FFF!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 border2px radius5 emptySection noBorder" id="section-4218110000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.0666667); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll shadow0 P0-top P0-bottom P0H noTopMargin block_positionnone radius10" id="row-5760410000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding: 10px 0px; margin-left: 150px; margin-right: 150px; background-color: rgb(255, 121, 31);"&gt;
&lt;div id="col-full-742" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-58132" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; outline: none; display: block; font-family: &amp;quot;Open Sans&amp;quot;, Helvetica, sans-serif !important;" data-google-font="Open+Sans"&gt;
&lt;div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize2" style="text-align: center; color: rgb(255, 255, 255); font-size: 36px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;Step #1&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-35741" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255);" data-bold="inherit" contenteditable="false"&gt;
Pants That Fit&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border2px noBorder" id="section-7360810000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.219608); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-8320210000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-bottom: 0px; padding-top: 0px;"&gt;
&lt;div id="col-full-995" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="tmp_video-39579" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169954720" data-hide-on="all" data-vimeo-autoplay="yes"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169954720?autoplay=1&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-57936" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFRFVJcnVBWllQdFk" id="link-6729-76" class="" target="_blank" style="color: rgb(238, 135, 0);"&gt;Download Step #1&lt;/a&gt; &lt;/b&gt;as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-151" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" style="padding-top: 0px;"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 200px; padding-right: 200px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(255, 121, 31);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Homework&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border1px radius10 noBorder" id="section--46485" data-title="Homework" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 60px; outline: none; margin-top: 0px; border-color: rgb(204, 204, 204); background-color: rgba(230, 230, 230, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable" style="padding-left: 20px; padding-right: 20px;"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--57774" data-trigger="none" data-animate="fade" data-delay="500" data-title="3 column row" style="margin-bottom: 0px; outline: none; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-122" class="col-md-4 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-20806" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM"&gt;
&lt;img src="https://images.clickfunnels.com/20/d77bd031c511e6907a81acec2dd7ed/MP-Q_A-20160613.jpg" class="elIMG ximg" height="200" width="" alt="Moneypants Q&amp;amp;A" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-18844" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Questions &amp;amp; Answers&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-158" class="col-md-4 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-88768" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFanBtSUhaeGVfQ3c"&gt;
&lt;img src="https://images.clickfunnels.com/2e/166da02e9711e688190b7571a5e2b1/Point-Charts-20160501-13.jpg" class="elIMG ximg" height="200" alt="point charts" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFanBtSUhaeGVfQ3c" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-49193" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Point Charts&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-145" class="col-md-4 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-97130" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFVUpLSVhhQThyNmM"&gt;
&lt;img src="https://images.clickfunnels.com/14/647cf02e9a11e6886ee78bb474707b/crc2013-1.jpg" class="elIMG ximg" height="200" alt="US Census data" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFVUpLSVhhQThyNmM" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-28837" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;US Census Data&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--12052" data-trigger="none" data-animate="fade" data-delay="500" data-title="2 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-164" class="col-md-6 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-30341" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFYlZTUXRqSzFXQms"&gt;
&lt;img src="https://images.clickfunnels.com/15/d5c0302e9a11e6817c112a3dcc235a/CRC2013InfoGraphic.jpg" class="elIMG ximg" height="200" alt="US Census infographic" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFYlZTUXRqSzFXQms" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-33370" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;US Census Infographic&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-147" class="col-md-6 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-21387" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-imagelink="http://www.babycenter.com/cost-of-raising-child-calculator"&gt;
&lt;img src="https://images.clickfunnels.com/1e/e9dbb02e9b11e688190b7571a5e2b1/Babycenter-Temp.png" class="elIMG ximg" alt="babycenter.com" data-imagelink="http://www.babycenter.com/cost-of-raising-child-calculator" target="_blank" height="200"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-66486" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;babycenter.com&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans%7COpen+Sans+Condensed%7COpen+Sans" id="custom_google_font"&gt;
&lt;style id="button_style_tmp_headline1-49719"&gt;#tmp_headline1-49719 .elButtonFlat:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonBottomBorder:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonSubtle:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(49,49,49)),color-stop(1,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:linear-gradient(to bottom,rgb(49,49,49) 0%,#171717 100%);}#tmp_headline1-49719 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(49,49,49)),color-stop(0,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:linear-gradient(to bottom,rgb(49,49,49) 100%,#171717 0%);}#tmp_headline1-49719 .elButtonBorder{border:3px solid rgb(49,49,49)!important;color:rgb(49,49,49)!important;}#tmp_headline1-49719 .elButtonBorder:hover{background-color:rgb(49,49,49)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="button_style_tmp_headline1-87137"&gt;#tmp_headline1-87137 .elButtonFlat:hover{background-color:#f56300!important;}#tmp_headline1-87137 .elButtonBottomBorder:hover{background-color:#f56300!important;}#tmp_headline1-87137 .elButtonSubtle:hover{background-color:#f56300!important;}#tmp_headline1-87137 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(255,121,31)),color-stop(1,#f56300));background-image:-o-linear-gradient(bottom,rgb(255,121,31) 0%,#f56300 100%);background-image:-moz-linear-gradient(bottom,rgb(255,121,31) 0%,#f56300 100%);background-image:-webkit-linear-gradient(bottom,rgb(255,121,31) 0%,#f56300 100%);background-image:-ms-linear-gradient(bottom,rgb(255,121,31) 0%,#f56300 100%);background-image:linear-gradient(to bottom,rgb(255,121,31) 0%,#f56300 100%);}#tmp_headline1-87137 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(255,121,31)),color-stop(0,#f56300));background-image:-o-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 0%);background-image:-moz-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 0%);background-image:-webkit-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 0%);background-image:-ms-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 0%);background-image:linear-gradient(to bottom,rgb(255,121,31) 100%,#f56300 0%);}#tmp_headline1-87137 .elButtonGradient2{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(255,121,31)),color-stop(1,#f56300));background-image:-o-linear-gradient(bottom,rgb(255,121,31) 30%,#f56300 80%);background-image:-moz-linear-gradient(bottom,rgb(255,121,31) 30%,#f56300 80%);background-image:-webkit-linear-gradient(bottom,rgb(255,121,31) 30%,#f56300 80%);background-image:-ms-linear-gradient(bottom,rgb(255,121,31) 30%,#f56300 80%);background-image:linear-gradient(to bottom,rgb(255,121,31) 30%,#f56300 80%);}#tmp_headline1-87137 .elButtonGradient2:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(255,121,31)),color-stop(0,#f56300));background-image:-o-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 30%);background-image:-moz-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 30%);background-image:-webkit-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 30%);background-image:-ms-linear-gradient(bottom,rgb(255,121,31) 100%,#f56300 30%);background-image:linear-gradient(to bottom,rgb(255,121,31) 100%,#f56300 30%);}#tmp_headline1-87137 .elButtonBorder{border:3px solid rgb(255,121,31)!important;color:rgb(255,121,31)!important;}#tmp_headline1-87137 .elButtonBorder:hover{background-color:rgb(255,121,31)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="bullet_list_icon_color_tmp_list-95270"&gt;#tmp_list-95270 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px shadow0 bgNoRepeat emptySection activeSection_topBorder0 activeSection_bottomBorder0 radius10 cornersAll" id="section--58804-132" data-title="Q&amp;amp;A Step 1 pt 2" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 40px; outline: none; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable" style="padding-left: 0px; padding-right: 0px;"&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890-123" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row - Clone" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-151-141" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" style="padding-top: 0px;"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137-142" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 160px; padding-right: 160px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(255, 121, 31);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Questions &amp;amp; Answers&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-22237" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; padding-left: 100px; padding-right: 100px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Below is a list of questions people frequently ask about Step #1.&amp;nbsp;&lt;span style="color: inherit;"&gt;If your question isn't answered below, you can always contact us:&amp;nbsp;&lt;/span&gt;&lt;b style="color: inherit;"&gt;help@captainmoneypants.com&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--63418" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-left: 40px; padding-right: 40px; margin-left: 0px; margin-right: 0px;"&gt;
&lt;div id="col-full-156" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elBullet elMargin0 de-editable" id="tmp_list-95270" data-de-type="list" data-de-editing="false" data-title="list" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;ul class="ne elBulletList listSize1 listIconBlack listBorder0 listIcon4" data-bold="inherit" contenteditable="false" bullet-color="rgb(255, 121, 31)"&gt;
&lt;li&gt;&lt;b&gt;&lt;a href="#tmp_image-75491-180" id="link-7616-324" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Aren’t you worried that your kids will just focus on money? That they&amp;nbsp;won’t do anything out of the goodness of their hearts?&lt;/a&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;/span&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;b&gt;&lt;a href="#img-74098-163" id="link-2129-435" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Why do I pay my kids for things they should be doing anyhow? Isn’t this bribery?&lt;/a&gt;&lt;/b&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;b&gt;&lt;a href="#img-18210-122" id="link-155-35" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Why should I pay my kids for helping out around the house? After all, as a parent, I don’t get paid for what I do.&lt;/a&gt;&lt;/b&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;b&gt;&lt;a href="#img-66469-148" id="link-8816-156" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;How did you guys come up with this system? Did you study psychology in school?&lt;/a&gt;&lt;/b&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;/span&gt;&lt;a href="#img-44990-133" id="link-2926-416" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Why do you pay your kids money instead of giving them regular&amp;nbsp;rewards?&lt;/a&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;/span&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;b&gt;&lt;a href="#img-58196-114" id="link-2728-58" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;My kids’ schedules don’t have enough time for as many chores as they selected. If we homeschooled or didn’t have after school activities it would be easier. I think we need to choose fewer chores and make them worth more.&lt;/a&gt;&lt;/b&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;b&gt;&lt;a href="#img-19724-165" id="link-3598-458" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Why do you have ten daily jobs, ten daily habits, and ten weekly jobs? Is there a reason for that?&lt;/a&gt;&lt;/b&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;b&gt;&lt;a href="#img-95751-110" id="link-1671-314" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;My husband makes over $100,000 a year, but just barely. If we find this chart is not working financially we can just move to chart B, right? Or would it be better for the kids to start with chart B and move to C if needed?&lt;/a&gt;&lt;/b&gt;&lt;/span&gt;&lt;/li&gt;&lt;li&gt;&lt;span style="color: inherit; line-height: 1.42857; background-color: rgba(230, 230, 230, 0);"&gt;&lt;b&gt;&lt;a href="#tmp_image-29189-162" id="link-8113-209" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Can I modify the point chart values? Can I change how much each job is worth?&amp;nbsp;&lt;/a&gt;&lt;/b&gt;&lt;/span&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;&lt;div class="de elSeperator elMargin0 de-editable" id="tmp_divider-61847" data-de-type="divider" data-de-editing="false" data-title="Divider" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="elDivider elDividerStyle1 elDividerColor3"&gt;
&lt;div class="elDividerInner"&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--63418-159" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-left: 0px; padding-right: 0px;"&gt;
&lt;div id="col-full-156-175" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" style="margin-left: 0px; margin-right: 0px; padding-left: 0px; padding-right: 0px;"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-75491-180" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/84/f52ee04de111e69c46731f5ead6411/MP-Q_A-20160613.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-98927-120" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/81/9736d04de111e6a16257cf6bc314d7/MP-Q_A-201606132.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-74098-163" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 40px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/82/5e7e704de111e6b9d0d7db5a64963c/MP-Q_A-201606133.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-18210-122" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 40px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/82/bb92904de111e69c46731f5ead6411/MP-Q_A-201606134.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-66469-148" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 40px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/83/7482504de111e6a16257cf6bc314d7/MP-Q_A-201606135.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-44064-183" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/84/3d29804de111e687a1ad875f52db96/MP-Q_A-201606136.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-44990-133" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/84/4789c04de111e68c42f9cd20751fd7/MP-Q_A-201606137.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-58196-114" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/85/5b1ca04de111e69bc8a5f769ede235/MP-Q_A-201606138.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-94106-173" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/85/4460504de111e69572a18536c921cb/MP-Q_A-201606139.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-19724-165" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/85/fb7b504de111e69bc8a5f769ede235/MP-Q_A-2016061310.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-95751-110" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/86/66e7504de111e68c42f9cd20751fd7/MP-Q_A-2016061311.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-29189-162" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/86/9d87b04de111e69d95773532869986/MP-Q_A-2016061312.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-76614-169" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 30px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/86/c079004de111e68c83392ba2c1b18c/MP-Q_A-2016061313.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;style id="bullet_list_icon_color_tmp_list-95270-167"&gt;#tmp_list-95270-167 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;
</textarea>
</li>
</ul>
</div>
<div data-cf-lesson-template="true">
<ul>
<li>
<a href="#" class="lesson-link" id="1-3">
<span data-cf-lesson-name="true">Step #2: Bring the Family Together</span>
</a>
<span data-cf-lesson-video="true" class="lesson-video hide"></span>
<textarea class="hide" data-cf-lesson-description="true">&lt;style id="button_style_tmp_button-23022"&gt;#tmp_button-23022 .elButtonFlat:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonBottomBorder:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonSubtle:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(25,56,71)),color-stop(1,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:linear-gradient(to bottom,rgb(25,56,71) 0%,#0e2029 100%);}#tmp_button-23022 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(25,56,71)),color-stop(0,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:linear-gradient(to bottom,rgb(25,56,71) 100%,#0e2029 0%);}#tmp_button-23022 .elButtonBorder{border:3px solid rgb(25,56,71)!important;color:rgb(25,56,71)!important;}#tmp_button-23022 .elButtonBorder:hover{background-color:rgb(25,56,71)!important;color:#FFF!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 border2px radius5 emptySection noBorder" id="section-4218110000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.0666667); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll shadow0 P0-top P0-bottom P0H noTopMargin block_positionnone radius10" id="row-5760410000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-left: 0px; padding-right: 0px; margin-left: 150px; margin-right: 150px; padding-top: 10px; background-color: rgb(93, 82, 163);"&gt;
&lt;div id="col-full-742" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper hiddenElementTools de-editable" id="tmp_headline1-58132" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; outline: none; display: block; font-family: &amp;quot;Open Sans&amp;quot;, Helvetica, sans-serif !important;" data-google-font="Open+Sans"&gt;
&lt;div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize2" style="text-align: center; color: rgb(255, 255, 255); font-size: 36px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;Step #2&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-35741" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255);" data-bold="inherit" contenteditable="false"&gt;
Bring the Family Together&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border2px noBorder" id="section-7360810000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.219608); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-8320210000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-995" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="tmp_video-39579" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169805436" data-hide-on="all" data-vimeo-autoplay="yes"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169805436?autoplay=1&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-73272" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: left; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFeEdpeDJ0dFFPWUE" id="link-1127-74" class="" target="_blank" style="color: rgb(73, 0, 156);"&gt;Download Step #2 (Part 1)&lt;/a&gt;&lt;/b&gt; as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="video-37008" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 40px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169805432" data-hide-on="all"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169805432?autoplay=0&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-40698" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: left; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFUDllN0NJSWxjRGM" id="link-8664-70" class="" target="_blank" style="color: rgb(87, 0, 145);"&gt;Download Step #2 (Part 2)&lt;/a&gt;&lt;/b&gt; as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890" data-trigger="none" data-animate="fade" data-delay="500" data-title="Homework" style="margin-bottom: 0px; outline: none; padding-top: 0px; padding-bottom: 0px; background-color: rgba(243, 16, 16, 0);"&gt;
&lt;div id="col-full-151" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" style="background-color: rgba(0, 0, 0, 0);"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 40px; cursor: pointer; outline: none; padding-left: 200px; padding-right: 200px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(93, 82, 163);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Homework&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border1px radius10 noBorder" id="section--46485" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; margin-top: 0px; border-color: rgb(204, 204, 204); background-color: rgba(230, 230, 230, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--57774" data-trigger="none" data-animate="fade" data-delay="500" data-title="3 column row" style="margin-bottom: 0px; outline: none; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-122" class="col-md-4 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-20806" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM"&gt;
&lt;img src="https://images.clickfunnels.com/92/97cc2031a711e6b3bb73a67a5d67b5/MP-Q_A-20160613.jpg" class="elIMG ximg" height="250" width="" alt="Moneypants Q&amp;amp;A" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-51199" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Questions &amp;amp; Answers&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-158" class="col-md-4 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-88768" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFanBtSUhaeGVfQ3c"&gt;
&lt;img src="https://images.clickfunnels.com/2e/166da02e9711e688190b7571a5e2b1/Point-Charts-20160501-13.jpg" class="elIMG ximg" height="250" alt="point charts" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFanBtSUhaeGVfQ3c" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-29573" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Point Charts&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-145" class="col-md-4 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-97130" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFeFRsUGVUZ09DTVk"&gt;
&lt;img src="https://images.clickfunnels.com/85/1377b031c611e68285830bd2ffc238/Kids-Expenses-20160518b-_Blank_.jpg" class="elIMG ximg" height="250" alt="US Census data" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFeFRsUGVUZ09DTVk" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-99577" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Kids' Expenses Worksheet&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--57774-141" data-trigger="none" data-animate="fade" data-delay="500" data-title="3 column row - Clone" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-122-172" class="col-md-4 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-20806-151" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMURKRVJVZWlsa1U"&gt;
&lt;img src="https://images.clickfunnels.com/9c/dfe2b031c711e68bb067354fe80621/Moneypants-Boss-20160517.jpg" class="elIMG ximg" height="250" width="" alt="Moneypants Q&amp;amp;A" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMURKRVJVZWlsa1U" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-88761" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Moneypants Boss&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-158-101" class="col-md-4 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-88768-187" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFS3VDU1VsVTh6SFk"&gt;
&lt;img src="https://images.clickfunnels.com/fb/704e3031e211e6a3e0e13d32ac2ec8/Moneypants-Boss-Chart-20160613-1.jpg" class="elIMG ximg" height="250" alt="point charts" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFS3VDU1VsVTh6SFk" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-32708" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Moneypants Boss Point Chart&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-145-127" class="col-md-4 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-97130-103" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMktyOXljekI3eWc"&gt;
&lt;img src="https://images.clickfunnels.com/fb/d954c031d811e6a4d673b2cf90d5cb/Moneypants-Jr.jpg" class="elIMG ximg" height="250" alt="US Census data" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMktyOXljekI3eWc" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-93565" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Moneypants Jr.&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--66734" data-trigger="none" data-animate="fade" data-delay="500" data-title="3 column row" style="margin-bottom: 0px; padding-top: 40px; padding-bottom: 0px; outline: none;"&gt;
&lt;div id="col-left-156" class="col-md-4 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-20544" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFdDdCZlhRUjR2NnM"&gt;
&lt;img src="https://images.clickfunnels.com/b9/8e2e0031c511e6b25227286c630f3c/Jobs-Inspection-Checklist-20160502-01.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFdDdCZlhRUjR2NnM" target="_blank" width="220"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-42211" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;
Job Inspection Checklist&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-119" class="col-md-4 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-44597" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFZWItUGltb3ZmOWs"&gt;
&lt;img src="https://images.clickfunnels.com/25/83d06031c611e6a52d01eaf592b8a9/Jobs-Inspection-Master-Checklist-20160517-01.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFZWItUGltb3ZmOWs" target="_blank" width="220"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-59854" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;
Master Checklist&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-120" class="col-md-4 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-21802" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFQTVOaTI2bUZyRkU"&gt;
&lt;img src="https://images.clickfunnels.com/aa/9fe8b0b12d11e6bc22fbcc45d43f20/Proper-Goalsetting-20160602-01.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFQTVOaTI2bUZyRkU" target="_blank" width="220"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-71187" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;
Proper Goal Setting&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--66734-179" data-trigger="none" data-animate="fade" data-delay="500" data-title="3 column row - Clone" style="margin-bottom: 0px; padding-top: 40px; padding-bottom: 0px; outline: none;"&gt;
&lt;div id="col-left-156-188" class="col-md-4 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-44597-173" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFYzlwNDdkWFRSN1k"&gt;
&lt;img src="https://images.clickfunnels.com/f2/a9d020aea911e6a68d1588b0b88986/Age-Appropriate-Jobs-20160517-01.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFYzlwNDdkWFRSN1k" target="_blank" width="220"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-59854-151" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;
Age-Appropriate Jobs&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-119-120" class="col-md-4 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-19582" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFcjE2TVB5WU52bGc"&gt;
&lt;img src="https://images.clickfunnels.com/b8/142fa0341f11e697b10b6c2f6f1b6c/Teamwork-v-Teamwork-20160607-1.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFcjE2TVB5WU52bGc" target="_blank" height="250"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-19435" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Teamwork vs. Teamwork&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-120-102" class="col-md-4 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-37102" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFd2dYVnRybjRKdVk"&gt;
&lt;img src="https://images.clickfunnels.com/6d/6c6400b13211e696577b63e0221c82/Proper-Goal-Setting-20160519-1.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFd2dYVnRybjRKdVk" target="_blank" width="220"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-19123" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;
Age-Appropriate Jobs&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans%7COpen+Sans+sans-serif%7C" id="custom_google_font"&gt;
&lt;style id="button_style_tmp_headline1-49719"&gt;#tmp_headline1-49719 .elButtonFlat:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonBottomBorder:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonSubtle:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(49,49,49)),color-stop(1,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:linear-gradient(to bottom,rgb(49,49,49) 0%,#171717 100%);}#tmp_headline1-49719 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(49,49,49)),color-stop(0,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:linear-gradient(to bottom,rgb(49,49,49) 100%,#171717 0%);}#tmp_headline1-49719 .elButtonBorder{border:3px solid rgb(49,49,49)!important;color:rgb(49,49,49)!important;}#tmp_headline1-49719 .elButtonBorder:hover{background-color:rgb(49,49,49)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="button_style_tmp_headline1-87137"&gt;#tmp_headline1-87137 .elButtonFlat:hover{background-color:#4d4488!important;}#tmp_headline1-87137 .elButtonBottomBorder:hover{background-color:#4d4488!important;}#tmp_headline1-87137 .elButtonSubtle:hover{background-color:#4d4488!important;}#tmp_headline1-87137 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(93,82,163)),color-stop(1,#4d4488));background-image:-o-linear-gradient(bottom,rgb(93,82,163) 0%,#4d4488 100%);background-image:-moz-linear-gradient(bottom,rgb(93,82,163) 0%,#4d4488 100%);background-image:-webkit-linear-gradient(bottom,rgb(93,82,163) 0%,#4d4488 100%);background-image:-ms-linear-gradient(bottom,rgb(93,82,163) 0%,#4d4488 100%);background-image:linear-gradient(to bottom,rgb(93,82,163) 0%,#4d4488 100%);}#tmp_headline1-87137 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(93,82,163)),color-stop(0,#4d4488));background-image:-o-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 0%);background-image:-moz-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 0%);background-image:-webkit-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 0%);background-image:-ms-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 0%);background-image:linear-gradient(to bottom,rgb(93,82,163) 100%,#4d4488 0%);}#tmp_headline1-87137 .elButtonGradient2{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(93,82,163)),color-stop(1,#4d4488));background-image:-o-linear-gradient(bottom,rgb(93,82,163) 30%,#4d4488 80%);background-image:-moz-linear-gradient(bottom,rgb(93,82,163) 30%,#4d4488 80%);background-image:-webkit-linear-gradient(bottom,rgb(93,82,163) 30%,#4d4488 80%);background-image:-ms-linear-gradient(bottom,rgb(93,82,163) 30%,#4d4488 80%);background-image:linear-gradient(to bottom,rgb(93,82,163) 30%,#4d4488 80%);}#tmp_headline1-87137 .elButtonGradient2:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(93,82,163)),color-stop(0,#4d4488));background-image:-o-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 30%);background-image:-moz-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 30%);background-image:-webkit-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 30%);background-image:-ms-linear-gradient(bottom,rgb(93,82,163) 100%,#4d4488 30%);background-image:linear-gradient(to bottom,rgb(93,82,163) 100%,#4d4488 30%);}#tmp_headline1-87137 .elButtonBorder{border:3px solid rgb(93,82,163)!important;color:rgb(93,82,163)!important;}#tmp_headline1-87137 .elButtonBorder:hover{background-color:rgb(93,82,163)!important;color:#FFF!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection" id="section--41891" data-title="Consistency Bonus" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 60px; outline: none; background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890-158" data-trigger="none" data-animate="fade" data-delay="500" data-title="Homework - Clone" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px; background-color: rgba(243, 16, 16, 0);" data-block-color="0074C7"&gt;
&lt;div id="col-full-151-181" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" style="background-color: rgba(0, 0, 0, 0);"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137-145" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 140px; padding-right: 140px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(93, 82, 163);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Chore Training Videos&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--51474" data-trigger="none" data-animate="fade" data-delay="500" data-title="4 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-176" class="col-md-3 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-34357" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579716"&gt;
&lt;img src="https://images.clickfunnels.com/5e/d078c031d311e68bb067354fe80621/Chore-Train-1---Bathrooms.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-left-176" class="col-md-3 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-75103" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579699"&gt;
&lt;img src="https://images.clickfunnels.com/5f/2a0a7031d311e68c59a3e053f38f6b/Chore-Train-2---Laundry.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-right-173" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-91700" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579712"&gt;
&lt;img src="https://images.clickfunnels.com/5f/3750e031d311e6a3e0e13d32ac2ec8/Chore-Train-3---Vacuum.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-130" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-51676" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579714"&gt;
&lt;img src="https://images.clickfunnels.com/5f/18573031d311e68285830bd2ffc238/Chore-Train-4---Floors.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--51474-148" data-trigger="none" data-animate="fade" data-delay="500" data-title="4 column row - Clone" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-176-117" class="col-md-3 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-92679" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579715"&gt;
&lt;img src="https://images.clickfunnels.com/5f/352e0031d311e6907a81acec2dd7ed/Chore-Train-5---Wipe-Table.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-left-176-137" class="col-md-3 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-75103-111" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579701"&gt;
&lt;img src="https://images.clickfunnels.com/65/b107e031d311e688c2d72bed1f8607/Chore-Train-6---Countertops.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-right-173-106" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-91700-167" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579711"&gt;
&lt;img src="https://images.clickfunnels.com/61/8efc8031d311e6a4d673b2cf90d5cb/Chore-Train-7---Dishes.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-130-157" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-51676-140" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579709"&gt;
&lt;img src="https://images.clickfunnels.com/60/1a5de031d311e6a3e0e13d32ac2ec8/Chore-Train-8---Mopping.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--51474-148-125" data-trigger="none" data-animate="fade" data-delay="500" data-title="4 column row - Clone - Clone" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-176-117-106" class="col-md-3 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-92679-117" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579700"&gt;
&lt;img src="https://images.clickfunnels.com/5f/e62e8031d311e683b191424456b81d/Chore-Train-9---Bedroom.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-left-176-137-104" class="col-md-3 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-75103-111-165" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/164277635"&gt;
&lt;img src="https://images.clickfunnels.com/5f/d6ec4031d311e6b3bb73a67a5d67b5/Chore-Train-10---Diaper.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-right-173-106-145" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-91700-167-110" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/153579702"&gt;
&lt;img src="https://images.clickfunnels.com/60/cbac8031d311e683b191424456b81d/Chore-Train-11---Potty-Train.jpg" class="elIMG1 ximg" height="auto" width=""&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-130-157-105" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoModalWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_videogallery1-48950" data-de-type="videogallery1" data-de-editing="false" data-title="Video Modal" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;a class="swipebox elIMG1btn" href="https://vimeo.com/180985330"&gt;
&lt;img src="https://images.clickfunnels.com/f8/b3a550795611e6830ac77cc6b95973/Chore-Train-21---Larry_s-Car-Wash.jpg" class="elIMG1 ximg" height="auto" width="auto"&gt;
&lt;/a&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection radius10" id="section--41891-147" data-title="Consistency Bonus - Clone" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 40px; outline: none; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable" style="padding-left: 0px; padding-right: 0px;"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890-158-115" data-trigger="none" data-animate="fade" data-delay="500" data-title="Homework - Clone" style="margin-bottom: 0px; outline: none; padding: 40px 30px 0px; background-color: rgba(243, 16, 16, 0);" data-block-color="0074C7"&gt;
&lt;div id="col-full-151-181-129" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" style="background-color: rgba(0, 0, 0, 0);"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137-145-119" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 140px; padding-right: 140px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(93, 82, 163);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Questions &amp;amp; Answers&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--74926" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-left: 40px; padding-right: 40px;"&gt;
&lt;div id="col-full-113" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elBullet elMargin0 de-editable" id="tmp_list-44821" data-de-type="list" data-de-editing="false" data-title="list" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;ul class="ne elBulletList listSize1 listIconBlack listBorder0 listIcon4" data-bold="inherit" contenteditable="false" bullet-color="rgb(255, 121, 31)"&gt;
&lt;li&gt;&lt;b&gt;&lt;a href="#tmp_image-74546" id="link-2638-256" class="" target="_self" style="color: rgb(0, 0, 5);"&gt;How do you divide the daily chores?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-92700" id="link-1718-450" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Should we give our kids more than two jobs?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-87085" id="link-1328-193" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Can my kids share chores? For example, my girls share a room. Should they share cleaning their room?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-25833" id="link-6411-10" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;My 4-year-old can’t reach the cupboards in our kitchen so he usually shares the dishes chore and works together with his brother putting things away. How would I pay my boys when they share jobs?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-25256" id="link-3627-129" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Why do you keep the same jobs for a year? Won’t the kids resent their job if they have to do it every day for an entire year?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857; background-color: rgba(255, 255, 255, 0);"&gt;&lt;a href="#img-66754" id="link-7488-325" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Can we change the chart and do a custom one?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857; background-color: rgba(255, 255, 255, 0);"&gt;&lt;a href="#img-99964" id="link-2986-128" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;I seriously doubt my teenage son would be willing to do the dishes for only $0.10. Shouldn’t it be more like $5.00?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857; background-color: rgba(255, 255, 255, 0);"&gt;&lt;a href="#img-93764" id="link-4860-477" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;Should I pay my younger kids more for jobs since it is harder for them than for their older siblings to do that same work?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857; background-color: rgba(255, 255, 255, 0);"&gt;&lt;a href="#img-36396" id="link-6973-285" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;How do you handle the Sabbath? I know it is a personal decision but I am curious what you or other families have done. The basic day-to-day “work” still needs to get done. Do they do it without pay?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857; background-color: rgba(255, 255, 255, 0);"&gt;&lt;a href="#img-37095" id="link-1526-382" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;What do you do when there’s point chart dishonesty going on? Like when my son marks his sister’s point chart with a zero, or someone rips up someone else’s point chart? Or marks too many points on their own chart?&lt;/a&gt;&lt;/b&gt;&lt;br&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--31368" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-left: 0px; padding-right: 0px;"&gt;
&lt;div id="col-full-112" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-74546" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/ed/d8a0b04e0c11e69c46731f5ead6411/MP-Q_A-20160613.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-92700" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f1/4cb8d04e0c11e69e0c9f9c42cc6930/MP-Q_A-201606132.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-87085" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/ef/fa96504e0c11e6a16257cf6bc314d7/MP-Q_A-201606133.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-25833" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f0/68e8804e0c11e68c42f9cd20751fd7/MP-Q_A-201606134.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-25256" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f1/2bea604e0c11e6848e0151eecf9039/MP-Q_A-201606135.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-22218" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f1/7d17a04e0c11e6b50f93b1e3224399/MP-Q_A-201606136.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-31081" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f2/7d70a04e0c11e69c46731f5ead6411/MP-Q_A-201606137.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-66754" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 50px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f4/4b52d04e0c11e6b9d0d7db5a64963c/MP-Q_A-201606138.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-99964" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f2/abd3a04e0c11e6ab5bffe3494d734f/MP-Q_A-201606139.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-61248" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f3/1607204e0c11e69d95773532869986/MP-Q_A-2016061310.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-51725" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f3/ded5604e0c11e6848e0151eecf9039/MP-Q_A-2016061311.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-93764" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 40px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f4/b4c3004e0c11e69c46731f5ead6411/MP-Q_A-2016061312.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-36396" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f4/d0d6804e0c11e69d95773532869986/MP-Q_A-2016061313.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-70314" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f5/456a404e0c11e68c42f9cd20751fd7/MP-Q_A-2016061314.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-37095" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f5/ab58004e0c11e69bc8a5f769ede235/MP-Q_A-2016061315.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-85633" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/f6/5c58804e0c11e68c83392ba2c1b18c/MP-Q_A-2016061316.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;style id="bullet_list_icon_color_tmp_list-44821"&gt;#tmp_list-44821 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;
</textarea>
</li>
</ul>
</div>
<div data-cf-lesson-template="true">
<ul>
<li>
<a href="#" class="lesson-link" id="1-4">
<span data-cf-lesson-name="true">Step #3: Get to Work!</span>
</a>
<span data-cf-lesson-video="true" class="lesson-video hide"></span>
<textarea class="hide" data-cf-lesson-description="true">&lt;style id="button_style_tmp_button-23022"&gt;#tmp_button-23022 .elButtonFlat:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonBottomBorder:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonSubtle:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(25,56,71)),color-stop(1,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:linear-gradient(to bottom,rgb(25,56,71) 0%,#0e2029 100%);}#tmp_button-23022 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(25,56,71)),color-stop(0,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:linear-gradient(to bottom,rgb(25,56,71) 100%,#0e2029 0%);}#tmp_button-23022 .elButtonBorder{border:3px solid rgb(25,56,71)!important;color:rgb(25,56,71)!important;}#tmp_button-23022 .elButtonBorder:hover{background-color:rgb(25,56,71)!important;color:#FFF!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 border2px radius5 emptySection noBorder" id="section-4218110000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.0666667); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll shadow0 P0-top P0-bottom P0H noTopMargin block_positionnone radius10" id="row-5760410000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-left: 0px; padding-right: 0px; margin-left: 150px; margin-right: 150px; background-color: rgb(153, 204, 51);"&gt;
&lt;div id="col-full-742" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-58132" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; outline: none; display: block; font-family: &amp;quot;Open Sans&amp;quot;, Helvetica, sans-serif !important;" data-google-font="Open+Sans"&gt;
&lt;div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize2" style="text-align: center; color: rgb(255, 255, 255); font-size: 36px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;Step #3&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-35741" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255);" data-bold="inherit" contenteditable="false"&gt;Get to Work!&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border2px noBorder" id="section-7360810000" data-title="Section" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.219608); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-8320210000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-995" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="tmp_video-39579" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169805433" data-hide-on="all" data-vimeo-autoplay="yes"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169805433?autoplay=1&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-40495" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: left; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFTUY3a1FleWpiNUk" id="link-2367-367" class="" target="_blank" style="color: rgb(59, 161, 0);"&gt;Download Step #3 (Part 1)&lt;/a&gt;&lt;/b&gt; as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="video-37008" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 50px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169805434" data-hide-on="all"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169805434?autoplay=0&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-72965" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: left; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFbGVmS24xbDREVHc" id="link-7618-249" class="" target="_blank" style="color: rgb(48, 161, 0);"&gt;Download Step #3 (Part 2)&lt;/a&gt;&lt;/b&gt; as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-151" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 200px; padding-right: 200px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(153, 204, 51);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Homework&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border1px radius10 noBorder" id="section--46485" data-title="Section" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 60px; outline: none; margin-top: 0px; border-color: rgb(204, 204, 204); background-color: rgba(230, 230, 230, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--57774" data-trigger="none" data-animate="fade" data-delay="500" data-title="3 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-left-122" class="col-md-4 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-20806" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; display: block;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM"&gt;
&lt;img src="https://images.clickfunnels.com/cb/42de902e9911e6b99d551922aa8e40/MP-Q_A-20160506.jpg" class="elIMG ximg" height="250" width="" alt="Moneypants Q&amp;amp;A" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-74818" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;
Questions &amp;amp; Answers&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-158" class="col-md-4 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-88768" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMktyOXljekI3eWc"&gt;
&lt;img src="https://images.clickfunnels.com/fb/d954c031d811e6a4d673b2cf90d5cb/Moneypants-Jr.jpg" class="elIMG ximg" height="250" alt="point charts" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMktyOXljekI3eWc" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-85699" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Moneypants Jr.&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-145" class="col-md-4 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-97130" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFQUdYWU5aeFZkZm8"&gt;
&lt;img src="https://images.clickfunnels.com/e3/80c47031d911e68285830bd2ffc238/Laundry-Chart-20160101.jpg" class="elIMG ximg" height="250" alt="US Census data" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFQUdYWU5aeFZkZm8" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-44042" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Sample Laundry Schedule&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--47789" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-top: 40px; padding-bottom: 0px; outline: none;"&gt;
&lt;div id="col-full-177" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elVideoWidth100 elMargin0 elVideoSkin7 de-editable" id="tmp_video-38170" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" data-video-type="vimeo" style="margin-top: 0px; cursor: pointer; outline: none;" data-vimeo-url="https://vimeo.com/141115238"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/141115238?autoplay=0&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-45105" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: left; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFSU96YkVpaVZycTg" id="link-5038-338" class="" target="_blank" style="color: rgb(55, 166, 0);"&gt;Download the Consistency Bonus&lt;/a&gt;&lt;/b&gt;&amp;nbsp;as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection radius10" id="section--55230" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 40px; outline: none; margin-top: 20px; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable" style="padding-left: 0px; padding-right: 0px;"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890-101" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row - Clone" style="margin-bottom: 0px; outline: none; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-151-114" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137-174" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 140px; padding-right: 140px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(153, 204, 51);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Questions &amp;amp; Answers&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--57324" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-left: 40px; padding-right: 40px; outline: none; padding-bottom: 0px;"&gt;
&lt;div id="col-full-173" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elBullet elMargin0 de-editable" id="tmp_list-52025" data-de-type="list" data-de-editing="false" data-title="list" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;ul class="ne elBulletList listSize1 listIconBlack listBorder0 listIcon4" data-bold="inherit" contenteditable="false" bullet-color="rgb(255, 121, 31)"&gt;
&lt;li&gt;&lt;b&gt;&lt;a href="#img-65818" id="link-1846-248" class="" target="_self" style="color: rgb(0, 0, 8);"&gt;What if my kids can’t get their jobs done before the 30-minute timer?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-65818" id="link-7782-451" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;When should I have my kids do chores?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-18515" id="link-3130-140" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;What do you do when one kid can’t do their chore because their brother or sister hasn’t finished and is in the way? You know, like when one person’s job is dependent on another person getting their job done first?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-94714" id="link-2073-144" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;How do you teach 2- and 3-year-olds to work?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-94714" id="link-425-446" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Is Job Time different for very young children?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-85741" id="link-213-408" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;I have 3-year-old twins and a four-year-old who just started new jobs, and it’s overwhelming to try to train them all. It takes too much time and energy, not to mention patience. What do I do?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-90899" id="link-3625-68" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Teaching all my kids all their new jobs at once was too overwhelming. What do I do?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-90899" id="link-8420-106" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;How do you give out the points for habits that are more subjective? For example, does the child decide if they’ve been a peacemaker? Or do the parents try to observe a specific instance of peacemaking? Or give an overall rating of how the child has done at peacemaking that day?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-12247" id="link-223-422" class="" target="_self" style="color: rgb(0, 0, 8);"&gt;How does your family determine behavior points? Is it all or nothing? Or do you take points away during the day for fighting, bad manners, or disobedience? Do they have to have a perfect day to get the points or can they earn partial points?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--57324-171" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row - Clone" style="margin-bottom: 0px; padding: 0px 80px; outline: none;"&gt;
&lt;div id="col-full-173-137" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elBullet elMargin0 de-editable" id="list-95445-105" data-de-type="list" data-de-editing="false" data-title="list" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;ul class="ne elBulletList listSize1 listIconBlack listBorder0 listIcon4" data-bold="inherit" contenteditable="false" bullet-color="rgb(255, 121, 31)"&gt;
&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-25088" id="link-7824-37" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Non-Monetary Rewards&lt;/a&gt;&lt;/b&gt;&lt;br&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-21277" id="link-2534-156" class="" target="_self" style="color: rgb(0, 0, 5);"&gt;Weekly Rewards&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-21277" id="link-2054-209" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;The Peacemaking Habit&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-21277" id="link-3632-465" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Car Trips&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-65179" id="link-6524-85" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Fighting vs. Peacemaking&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-65179" id="link-5966-213" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;The Penultimate Goal: The Consistency Bonus&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--57324-171-173" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row - Clone - Clone" style="margin-bottom: 0px; padding-left: 40px; padding-right: 40px; outline: none; padding-top: 0px;"&gt;
&lt;div id="col-full-173-137-145" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elBullet elMargin0 de-editable" id="list-56952-141-152" data-de-type="list" data-de-editing="false" data-title="list" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;ul class="ne elBulletList listSize1 listIconBlack listBorder0 listIcon4" data-bold="inherit" contenteditable="false" bullet-color="rgb(255, 121, 31)"&gt;
&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-68564" id="link-4409-338" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;What amount of time do you give for each chore?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-95828" id="link-6091-92" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Is it better to split the job into something my kids can accomplish rather than give them too much that they can only do half the job?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-95828" id="link-6066-490" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;What if my kid only finishes half the job? Do I pay him half?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-65096" id="link-3161-336" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;If the bathroom, let’s say sink, is clean from the night before does my child still need to wipe it? Or should I split up the job between counters one day and toilets the next, since they are pretty clean still?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-28249" id="link-2404-450" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;If I have to do their chores for them (like dishes when people are coming over for dinner), I mark a negative which means they have to pay me back. Is that okay?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-28249" id="link-3308-480" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;Do playing Monopoly and reading a book need to be earned? My son reads all the time and I was making it a privilege in my previous parenting system. But I don’t know about Monopoly.&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#tmp_image-72414" id="link-5030-243" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;My daughter has a little friend who always shows up to play. I was thinking of charging her a play fee when she chooses to play before her chores are done. Maybe $5. What do you think?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-92050" id="link-4946-422" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;What do I do if the 30-minute job timer goes off and my child isn’t finished with their job?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-56036" id="link-241-246" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;I’m curious how laundry is handled at your house. Do you have a system that works?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b style="color: inherit; line-height: 1.42857;"&gt;&lt;a href="#img-93399" id="link-6214-332" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;How does babysitting work on the point chart?&lt;/a&gt;&lt;/b&gt;&lt;br&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--14819" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-left: 0px; padding-right: 0px; outline: none;"&gt;
&lt;div id="col-full-144" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-65818" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/71/4081504e2811e6ab6837c90de62af4/MP-Q_A-20160613.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-11068" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 7px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/71/e881204e2811e69bc8a5f769ede235/MP-Q_A-201606132.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-18515" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/72/5525a04e2811e6b9d0d7db5a64963c/MP-Q_A-201606133.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-80839" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 35px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/72/d3a4704e2811e69bc8a5f769ede235/MP-Q_A-201606134.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-94714" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/73/5382d04e2811e6b50f93b1e3224399/MP-Q_A-201606135.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-73608" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 7px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/74/db82604e2811e69e0c9f9c42cc6930/MP-Q_A-201606136.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-58246" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 8px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/75/3450c04e2811e68c42f9cd20751fd7/MP-Q_A-201606137.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-27727" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/75/a589204e2811e6ab5bffe3494d734f/MP-Q_A-201606138.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-36429" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 38px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/75/a9a7d04e2811e6be404540a05dffd3/MP-Q_A-201606139.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-85741" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 30px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/76/7b4fb04e2811e6a16257cf6bc314d7/MP-Q_A-2016061310.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-65858" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 7px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/77/435aa04e2811e68c42f9cd20751fd7/MP-Q_A-2016061311.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-90899" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/79/bda9704e2811e69e0c9f9c42cc6930/MP-Q_A-2016061312.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-97062" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 30px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/78/fcca704e2811e6b9d0d7db5a64963c/MP-Q_A-2016061313.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-12247" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/79/ef40c04e2811e6ab6837c90de62af4/MP-Q_A-2016061314.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-25088" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7a/6b4e904e2811e6a16257cf6bc314d7/MP-Q_A-2016061315.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-21277" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 8px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7b/5c17304e2811e6b50f93b1e3224399/MP-Q_A-2016061316.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-47095" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 7px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7b/7ac2c04e2811e6bf3cf9556035de82/MP-Q_A-2016061317.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-65179" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 8px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7c/037ac04e2811e69572a18536c921cb/MP-Q_A-2016061318.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-68564" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7c/8d1d204e2811e6bf3cf9556035de82/MP-Q_A-2016061319.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-95828" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7d/50bb404e2811e6a16257cf6bc314d7/MP-Q_A-2016061320.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-27830" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 8px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7d/aae9304e2811e687a1ad875f52db96/MP-Q_A-2016061321.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-65096" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7e/5867404e2811e68c42f9cd20751fd7/MP-Q_A-2016061322.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-28249" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; cursor: pointer; outline: none;"&gt;
&lt;img src="https://images.clickfunnels.com/7f/7967a04e2811e69bc8a5f769ede235/MP-Q_A-2016061323.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-72414" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/82/4ef5d04e2811e69c46731f5ead6411/MP-Q_A-2016061324.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-92050" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 6px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/7f/ca6dd04e2811e6ab5bffe3494d734f/MP-Q_A-2016061325.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-56036" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 9px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/80/70bff04e2811e6916f5f01ed2347bf/MP-Q_A-2016061326.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-80054" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 8px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/81/2da7504e2811e69572a18536c921cb/MP-Q_A-2016061327.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-93399" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 25px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/82/86ceb04e2811e6ab5bffe3494d734f/MP-Q_A-2016061328.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-93861" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/82/8b3b804e2811e69e0c9f9c42cc6930/MP-Q_A-2016061329.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-15319" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/82/e73e304e2811e69572a18536c921cb/MP-Q_A-2016061330.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans%7COpen+Sans+Condensed%7COpen+Sans" id="custom_google_font"&gt;
&lt;style id="button_style_tmp_headline1-49719"&gt;#tmp_headline1-49719 .elButtonFlat:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonBottomBorder:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonSubtle:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(49,49,49)),color-stop(1,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:linear-gradient(to bottom,rgb(49,49,49) 0%,#171717 100%);}#tmp_headline1-49719 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(49,49,49)),color-stop(0,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:linear-gradient(to bottom,rgb(49,49,49) 100%,#171717 0%);}#tmp_headline1-49719 .elButtonBorder{border:3px solid rgb(49,49,49)!important;color:rgb(49,49,49)!important;}#tmp_headline1-49719 .elButtonBorder:hover{background-color:rgb(49,49,49)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="button_style_tmp_headline1-87137"&gt;#tmp_headline1-87137 .elButtonFlat:hover{background-color:#81ab2b!important;}#tmp_headline1-87137 .elButtonBottomBorder:hover{background-color:#81ab2b!important;}#tmp_headline1-87137 .elButtonSubtle:hover{background-color:#81ab2b!important;}#tmp_headline1-87137 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(153,204,51)),color-stop(1,#81ab2b));background-image:-o-linear-gradient(bottom,rgb(153,204,51) 0%,#81ab2b 100%);background-image:-moz-linear-gradient(bottom,rgb(153,204,51) 0%,#81ab2b 100%);background-image:-webkit-linear-gradient(bottom,rgb(153,204,51) 0%,#81ab2b 100%);background-image:-ms-linear-gradient(bottom,rgb(153,204,51) 0%,#81ab2b 100%);background-image:linear-gradient(to bottom,rgb(153,204,51) 0%,#81ab2b 100%);}#tmp_headline1-87137 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(153,204,51)),color-stop(0,#81ab2b));background-image:-o-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 0%);background-image:-moz-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 0%);background-image:-webkit-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 0%);background-image:-ms-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 0%);background-image:linear-gradient(to bottom,rgb(153,204,51) 100%,#81ab2b 0%);}#tmp_headline1-87137 .elButtonGradient2{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(153,204,51)),color-stop(1,#81ab2b));background-image:-o-linear-gradient(bottom,rgb(153,204,51) 30%,#81ab2b 80%);background-image:-moz-linear-gradient(bottom,rgb(153,204,51) 30%,#81ab2b 80%);background-image:-webkit-linear-gradient(bottom,rgb(153,204,51) 30%,#81ab2b 80%);background-image:-ms-linear-gradient(bottom,rgb(153,204,51) 30%,#81ab2b 80%);background-image:linear-gradient(to bottom,rgb(153,204,51) 30%,#81ab2b 80%);}#tmp_headline1-87137 .elButtonGradient2:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(153,204,51)),color-stop(0,#81ab2b));background-image:-o-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 30%);background-image:-moz-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 30%);background-image:-webkit-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 30%);background-image:-ms-linear-gradient(bottom,rgb(153,204,51) 100%,#81ab2b 30%);background-image:linear-gradient(to bottom,rgb(153,204,51) 100%,#81ab2b 30%);}#tmp_headline1-87137 .elButtonBorder{border:3px solid rgb(153,204,51)!important;color:rgb(153,204,51)!important;}#tmp_headline1-87137 .elButtonBorder:hover{background-color:rgb(153,204,51)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="bullet_list_icon_color_tmp_list-52025"&gt;#tmp_list-52025 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;&lt;style id="bullet_list_icon_color_list-95445-105"&gt;#list-95445-105 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;&lt;style id="bullet_list_icon_color_list-56952-141-152"&gt;#list-56952-141-152 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;
</textarea>
</li>
</ul>
</div>
<div data-cf-lesson-template="true">
<ul>
<li>
<a href="#" class="lesson-link" id="1-5">
<span data-cf-lesson-name="true">Step #4: It's Payday!</span>
</a>
<span data-cf-lesson-video="true" class="lesson-video hide"></span>
<textarea class="hide" data-cf-lesson-description="true">&lt;style id="button_style_tmp_button-23022"&gt;#tmp_button-23022 .elButtonFlat:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonBottomBorder:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonSubtle:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(25,56,71)),color-stop(1,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:linear-gradient(to bottom,rgb(25,56,71) 0%,#0e2029 100%);}#tmp_button-23022 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(25,56,71)),color-stop(0,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:linear-gradient(to bottom,rgb(25,56,71) 100%,#0e2029 0%);}#tmp_button-23022 .elButtonBorder{border:3px solid rgb(25,56,71)!important;color:rgb(25,56,71)!important;}#tmp_button-23022 .elButtonBorder:hover{background-color:rgb(25,56,71)!important;color:#FFF!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 border2px radius5 emptySection noBorder" id="section-4218110000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.0666667); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll shadow0 P0-top P0-bottom P0H noTopMargin block_positionnone radius10" id="row-5760410000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-left: 0px; padding-right: 0px; margin-left: 150px; margin-right: 150px; background-color: rgb(0, 153, 255);"&gt;
&lt;div id="col-full-742" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper hiddenElementTools de-editable" id="tmp_headline1-58132" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; outline: none; display: block; font-family: &amp;quot;Open Sans&amp;quot;, Helvetica, sans-serif !important;" data-google-font="Open+Sans"&gt;
&lt;div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize2" style="text-align: center; color: rgb(255, 255, 255); font-size: 36px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;Step #4&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-35741" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255);" data-bold="inherit" contenteditable="false"&gt;It's Payday!&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border2px noBorder" id="section-7360810000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.219608); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-8320210000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-995" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="tmp_video-39579" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169805435" data-hide-on="all" data-vimeo-autoplay="yes"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169805435?autoplay=1&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-21515" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: left; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFQ05kTzJqV2Fkd0E" id="link-5443-354" class="" target="_blank" style="color: rgb(0, 127, 238);"&gt;Download Step #4&amp;nbsp;&lt;/a&gt;&lt;/b&gt;as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-151" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 200px; padding-right: 200px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(0, 153, 255);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Homework&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--28261" data-trigger="none" data-animate="fade" data-delay="500" data-title="4 column row" style="margin-bottom: 0px; outline: none; padding-bottom: 0px; padding-top: 40px;"&gt;
&lt;div id="col-left-144" class="col-md-3 innerContent col_left ui-resizable" data-col="left" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far Left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-62289" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM"&gt;
&lt;img src="https://images.clickfunnels.com/20/d77bd031c511e6907a81acec2dd7ed/MP-Q_A-20160613.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-38124" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;
Questions &amp;amp; Answers&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-left-181" class="col-md-3 innerContent col_right ui-resizable" data-col="center" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center left column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-26726" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFbHlCc3UtdjBJdDQ"&gt;
&lt;img src="https://images.clickfunnels.com/51/a7202031f311e6a4d673b2cf90d5cb/Vacation-Budget-Worksheet-20160525.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFbHlCc3UtdjBJdDQ" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-29103" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Vacation Budget Planner&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-center-right-117" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Center right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-68820" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFbVNha1F1dGlDRHM"&gt;
&lt;img src="https://images.clickfunnels.com/2d/066340327311e69584f956e7df478e/Behavior-Report-How-To-20160614.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFbVNha1F1dGlDRHM" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-27592" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Behavior Report How-To&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div id="col-right-122" class="col-md-3 innerContent col_right ui-resizable" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="Far right column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-67697" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFYktORWtQV2E3T0E"&gt;
&lt;img src="https://images.clickfunnels.com/40/f85dc0327511e6bcfae566f04a6899/Behavior-Report-20160614.jpg" class="elIMG ximg" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFYktORWtQV2E3T0E" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="headline-48349" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Behavior Report&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--38351" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-bottom: 0px; padding-top: 20px;"&gt;
&lt;div id="col-full-100" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-27182" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-imagelink="https://www.vidangel.com/"&gt;
&lt;img src="https://images.clickfunnels.com/db/e84900327311e6bcf85b20b5e24486/vidangel.png" class="elIMG ximg" height="" width="150" data-imagelink="https://www.vidangel.com/" target="_blank"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border1px radius10 noBorder" id="section--46485" data-title="Section" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 60px; outline: none; margin-top: 0px; border-color: rgb(204, 204, 204); background-color: rgba(230, 230, 230, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--78937" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-147" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elVideoWidth100 elMargin0 elVideoSkin7 de-editable" id="tmp_video-38412" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" data-video-type="vimeo" style="margin-top: 0px; cursor: pointer; outline: none;" data-vimeo-url="https://vimeo.com/164363456"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/164363456?autoplay=0&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px cornersAll shadow0 bgNoRepeat emptySection activeSection_topBorder0 activeSection_bottomBorder0 radius10" id="section--78508" data-title="Section" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 40px; outline: none; margin-top: 20px; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable" style="padding-left: 0px; padding-right: 0px;"&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890-152" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row - Clone" style="margin-bottom: 0px; outline: none; padding: 40px 30px 0px; margin-top: 0px;"&gt;
&lt;div id="col-full-151-100" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137-127" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 160px; padding-right: 160px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(0, 153, 255);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Questions &amp;amp; Answers&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--19843" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-left: 40px; padding-right: 40px; outline: none;"&gt;
&lt;div id="col-full-164" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elBullet elMargin0 de-editable" id="tmp_list-68464" data-de-type="list" data-de-editing="false" data-title="list" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;ul class="ne elBulletList listSize1 listIconBlack listBorder0 listIcon4" data-bold="inherit" contenteditable="false" bullet-color="rgb(255, 121, 31)"&gt;
&lt;li&gt;&lt;b&gt;&lt;a href="#tmp_image-82832" id="link-213-314" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;You talk about paying points. Do you mean one point is a penny?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#tmp_image-82832" id="link-7182-119" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;Is Payday different for very young children?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-37961" id="link-2066-251" class="" target="_self" style="color: rgb(0, 0, 5);"&gt;I noticed that at the end of the week they don’t get paid that much. Why?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-37754" id="link-5798-232" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;
I don’t want my kids borrowing money, but my kids don’t have enough money to start paying for their needs. What do I do?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-97906" id="link-7431-390" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;
If you have a kid that punches holes in the walls when he’s mad, do you make him pay for it?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--97499" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-left: 0px; padding-right: 0px; outline: none;"&gt;
&lt;div id="col-full-108" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-82832" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/57/9a5a004e3711e6a16257cf6bc314d7/MP-Q_A-20160613.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-37961" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/57/e0fff04e3711e6b50f93b1e3224399/MP-Q_A-201606132.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-37754" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 30px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/58/634f504e3711e68c42f9cd20751fd7/MP-Q_A-201606133.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-97906" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 4px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/58/dc4fe04e3711e6916f5f01ed2347bf/MP-Q_A-201606134.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-45575" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 8px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/59/7ed1704e3711e687a1ad875f52db96/MP-Q_A-201606135.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-72474" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/59/83da804e3711e6b50f93b1e3224399/MP-Q_A-201606136.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans%7COpen+Sans+Condensed%7COpen+Sans" id="custom_google_font"&gt;
&lt;style id="button_style_tmp_headline1-49719"&gt;#tmp_headline1-49719 .elButtonFlat:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonBottomBorder:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonSubtle:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(49,49,49)),color-stop(1,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:linear-gradient(to bottom,rgb(49,49,49) 0%,#171717 100%);}#tmp_headline1-49719 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(49,49,49)),color-stop(0,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:linear-gradient(to bottom,rgb(49,49,49) 100%,#171717 0%);}#tmp_headline1-49719 .elButtonBorder{border:3px solid rgb(49,49,49)!important;color:rgb(49,49,49)!important;}#tmp_headline1-49719 .elButtonBorder:hover{background-color:rgb(49,49,49)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="button_style_tmp_headline1-87137"&gt;#tmp_headline1-87137 .elButtonFlat:hover{background-color:#0081d6!important;}#tmp_headline1-87137 .elButtonBottomBorder:hover{background-color:#0081d6!important;}#tmp_headline1-87137 .elButtonSubtle:hover{background-color:#0081d6!important;}#tmp_headline1-87137 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(0,153,255)),color-stop(1,#0081d6));background-image:-o-linear-gradient(bottom,rgb(0,153,255) 0%,#0081d6 100%);background-image:-moz-linear-gradient(bottom,rgb(0,153,255) 0%,#0081d6 100%);background-image:-webkit-linear-gradient(bottom,rgb(0,153,255) 0%,#0081d6 100%);background-image:-ms-linear-gradient(bottom,rgb(0,153,255) 0%,#0081d6 100%);background-image:linear-gradient(to bottom,rgb(0,153,255) 0%,#0081d6 100%);}#tmp_headline1-87137 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(0,153,255)),color-stop(0,#0081d6));background-image:-o-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 0%);background-image:-moz-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 0%);background-image:-webkit-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 0%);background-image:-ms-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 0%);background-image:linear-gradient(to bottom,rgb(0,153,255) 100%,#0081d6 0%);}#tmp_headline1-87137 .elButtonGradient2{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(0,153,255)),color-stop(1,#0081d6));background-image:-o-linear-gradient(bottom,rgb(0,153,255) 30%,#0081d6 80%);background-image:-moz-linear-gradient(bottom,rgb(0,153,255) 30%,#0081d6 80%);background-image:-webkit-linear-gradient(bottom,rgb(0,153,255) 30%,#0081d6 80%);background-image:-ms-linear-gradient(bottom,rgb(0,153,255) 30%,#0081d6 80%);background-image:linear-gradient(to bottom,rgb(0,153,255) 30%,#0081d6 80%);}#tmp_headline1-87137 .elButtonGradient2:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(0,153,255)),color-stop(0,#0081d6));background-image:-o-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 30%);background-image:-moz-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 30%);background-image:-webkit-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 30%);background-image:-ms-linear-gradient(bottom,rgb(0,153,255) 100%,#0081d6 30%);background-image:linear-gradient(to bottom,rgb(0,153,255) 100%,#0081d6 30%);}#tmp_headline1-87137 .elButtonBorder{border:3px solid rgb(0,153,255)!important;color:rgb(0,153,255)!important;}#tmp_headline1-87137 .elButtonBorder:hover{background-color:rgb(0,153,255)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="bullet_list_icon_color_tmp_list-68464"&gt;#tmp_list-68464 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;
</textarea>
</li>
</ul>
</div>
<div data-cf-lesson-template="true">
<ul>
<li>
<a href="#" class="lesson-link" id="1-6">
<span data-cf-lesson-name="true">Step #5: Save, Shop, &amp; Spend</span>
</a>
<span data-cf-lesson-video="true" class="lesson-video hide"></span>
<textarea class="hide" data-cf-lesson-description="true">&lt;style id="button_style_tmp_button-23022"&gt;#tmp_button-23022 .elButtonFlat:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonBottomBorder:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonSubtle:hover{background-color:#0e2029!important;}#tmp_button-23022 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(25,56,71)),color-stop(1,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 0%,#0e2029 100%);background-image:linear-gradient(to bottom,rgb(25,56,71) 0%,#0e2029 100%);}#tmp_button-23022 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(25,56,71)),color-stop(0,#0e2029));background-image:-o-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-moz-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-webkit-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:-ms-linear-gradient(bottom,rgb(25,56,71) 100%,#0e2029 0%);background-image:linear-gradient(to bottom,rgb(25,56,71) 100%,#0e2029 0%);}#tmp_button-23022 .elButtonBorder{border:3px solid rgb(25,56,71)!important;color:rgb(25,56,71)!important;}#tmp_button-23022 .elButtonBorder:hover{background-color:rgb(25,56,71)!important;color:#FFF!important;}&lt;/style&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 border2px radius5 emptySection noBorder" id="section-4218110000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.0666667); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll shadow0 P0-top P0-bottom P0H noTopMargin block_positionnone radius10" id="row-5760410000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-left: 0px; padding-right: 0px; margin-left: 150px; margin-right: 150px; padding-top: 10px; background-color: rgb(204, 0, 102);"&gt;
&lt;div id="col-full-742" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper hiddenElementTools de-editable" id="tmp_headline1-58132" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; outline: none; display: block; font-family: &amp;quot;Open Sans&amp;quot;, Helvetica, sans-serif !important;" data-google-font="Open+Sans"&gt;
&lt;div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize2" style="text-align: center; color: rgb(255, 255, 255); font-size: 36px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;Step #5&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-35741" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255);" data-bold="inherit" contenteditable="false"&gt;Save, Shop, &amp;amp; Spend&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll radius0 shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border2px noBorder" id="section-7360810000" data-title="Section" data-block-color="0074C7" style="padding-top: 40px; padding-bottom: 0px; outline: none; border-color: rgba(47, 47, 47, 0.219608); background-color: rgba(255, 255, 255, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-8320210000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-995" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elMargin0 elVideoWidth100 elVideoSkin7 de-editable" id="tmp_video-39579" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; outline: none; cursor: pointer;" data-video-type="vimeo" data-vimeo-url="https://vimeo.com/169805439" data-hide-on="all" data-vimeo-autoplay="yes"&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/169805439?autoplay=1&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-57502" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: left; font-size: 14px;" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;&lt;a href="https://drive.google.com/open?id=0B0MyrcjLfzRFWngySjdhM04xTDg" id="link-3969-307" class="" target="_blank" style="color: rgb(173, 0, 121);"&gt;Download Step #5&lt;/a&gt;&lt;/b&gt; as an .mp3 file to listen to on your phone or in the car while you're on the go!&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-151" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 200px; padding-right: 200px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(204, 0, 102);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Homework&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--49619" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-bottom: 0px; padding-top: 40px; outline: none;"&gt;
&lt;div id="col-full-165" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-91718" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none;" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM"&gt;
&lt;img src="https://images.clickfunnels.com/20/d77bd031c511e6907a81acec2dd7ed/MP-Q_A-20160613.jpg" class="elIMG ximg" height="250" data-imagelink="https://drive.google.com/open?id=0B0MyrcjLfzRFMVAzdFVwcWFESmM" target="_blank"&gt;
&lt;/div&gt;&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-61984" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center; font-size: 12px;" data-bold="inherit" contenteditable="false"&gt;Questions &amp;amp; Answers&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  borderSolid cornersAll shadow0 bgNoRepeat activeSection_topBorder0 activeSection_bottomBorder0 emptySection border1px radius10 noBorder" id="section--46485" data-title="Section" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 60px; outline: none; margin-top: 0px; border-color: rgb(204, 204, 204); background-color: rgba(230, 230, 230, 0);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable"&gt;
&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--19790" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; outline: none; padding-top: 40px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-152" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elVideoWrapper de-video-block elVideoWidth100 elMargin0 elVideoSkin7 de-editable" id="tmp_video-14919" data-de-type="video" data-de-editing="false" data-title="video" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" data-video-type="vimeo" style="margin-top: 0px; cursor: pointer; outline: none;" data-vimeo-url="https://vimeo.com/170578848" data-vimeo-width=""&gt;
&lt;div class="elVideoplaceholder"&gt;
&lt;div class="elVideoplaceholder_inner"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class="elVideo" style="display: none;"&gt;&lt;iframe width="640" height="360" src="//player.vimeo.com/video/170578848?autoplay=0&amp;amp;title=0&amp;amp;byline=0&amp;amp;wmode=transparent" frameborder="0" allowfullscreen="" wmode="opaque"&gt;&lt;/iframe&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;div class="container midContainer noTopMargin padding40-top padding40-bottom padding40H  noBorder borderSolid border3px cornersAll shadow0 bgNoRepeat emptySection activeSection_topBorder0 activeSection_bottomBorder0 radius10" id="section--58178" data-title="Section" data-block-color="0074C7" style="padding-top: 0px; padding-bottom: 40px; outline: none; margin-top: 20px; background-color: rgb(255, 255, 255);" data-trigger="none" data-animate="fade" data-delay="500"&gt;
&lt;div class="containerInner ui-sortable" style="padding-left: 0px; padding-right: 0px;"&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--70890-153" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row - Clone" style="margin-bottom: 0px; outline: none; padding-top: 0px; padding-bottom: 0px;"&gt;
&lt;div id="col-full-151-157" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" style="padding-top: 40px; padding-left: 30px; padding-right: 30px;"&gt;
&lt;div class="de elHeadlineWrapper de-editable" id="tmp_headline1-87137-163" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 0px; cursor: pointer; outline: none; padding-left: 160px; padding-right: 160px;"&gt;
&lt;div class="ne elHeadline hsSize3 lh3 elMargin0 elBGStyle0 hsTextShadow0 elInputBR5 elHeadlineIcon_none" style="text-align: center; font-size: 24px; color: rgb(255, 255, 255); background-color: rgb(204, 0, 102);" data-bold="inherit" contenteditable="false"&gt;&lt;b&gt;
Questions &amp;amp; Answers&lt;/b&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--59782" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-left: 40px; padding-right: 40px; outline: none;"&gt;
&lt;div id="col-full-130" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elBullet elMargin0 de-editable" id="tmp_list-35712" data-de-type="list" data-de-editing="false" data-title="list" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;"&gt;
&lt;ul class="ne elBulletList listSize1 listIconBlack listBorder0 listIcon4" data-bold="inherit" bullet-color="rgb(255, 121, 31)" contenteditable="false"&gt;
&lt;li&gt;&lt;b&gt;&lt;a href="#tmp_image-85258" id="link-2386-112" class="" target="_self" style="color: rgb(0, 0, 3);"&gt;I want my kids to play the piano, but my kids don’t like it and are not willing to spend the money on lessons. I’m not willing to give that up. Should I just go ahead and pay for the classes myself?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;
&lt;a href="#img-25578" id="link-3695-36" class="" target="_self" style="color: rgb(0, 0, 5);"&gt;What happens if a child is sick or simply not at home during daily chore time?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-25578" id="link-1225-188" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;People give our family a lot of hand me down clothes and toys. My kids don’t really need to buy stuff. Furthermore, their grandparents pay for dance classes and soccer. Should I just have my kids save the money they earn?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-12261" id="link-1509-346" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;Do we make them pay for family trips to Disneyland?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-20128" id="link-2994-424" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;What do you mean by mastering a job? How can you tell when a child has mastered a job and can move on to a new job?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-83690" id="link-4154-1" class="" target="_self" style="color: rgb(0, 0, 0);"&gt;I read that a good way to motivate your kids to make their beds is to take it away if they don’t take care of it. What do you think?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;&lt;b&gt;&lt;a href="#img-85598" id="link-3095-388" class="" target="_self" style="color: rgb(0, 0, 8);"&gt;What do I do when I find out my kids stole their sibling’s money?&lt;/a&gt;&lt;/b&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row--65546" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="margin-bottom: 0px; padding-left: 0px; padding-right: 0px; outline: none;"&gt;
&lt;div id="col-full-125" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;"&gt;
&lt;div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin"&gt;
&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-85258" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none; display: block;"&gt;
&lt;img src="https://images.clickfunnels.com/1a/3c85704e4611e6ab5bffe3494d734f/MP-Q_A-20160613.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="tmp_image-29162" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 4px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1a/88a9a04e4611e6848e0151eecf9039/MP-Q_A-201606132.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-12063" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1b/0a5cc04e4611e68c83392ba2c1b18c/MP-Q_A-201606133.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-53507" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 27px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1b/8be8d04e4611e6b50f93b1e3224399/MP-Q_A-201606134.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-81395" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1c/7d4db04e4611e68c42f9cd20751fd7/MP-Q_A-201606135.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-25578" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1c/d977704e4611e687a1ad875f52db96/MP-Q_A-201606136.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-87586" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 27px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1d/4001704e4611e6b50f93b1e3224399/MP-Q_A-201606137.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-72658" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 28px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1d/ebaac04e4611e69572a18536c921cb/MP-Q_A-201606138.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-12261" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 60px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1e/7b19804e4611e6848e0151eecf9039/MP-Q_A-201606139.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-20128" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1f/cc51a04e4611e687a1ad875f52db96/MP-Q_A-2016061310.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-22425" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 4px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/1f/da82704e4611e69572a18536c921cb/MP-Q_A-2016061311.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-83690" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 20px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/21/1944004e4611e69572a18536c921cb/MP-Q_A-2016061312.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-34610" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 5px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/22/7ddd104e4611e69d95773532869986/MP-Q_A-2016061313.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;&lt;div class="de elImageWrapper de-image-block elAlign_center elMargin0 de-editable" id="img-85598" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 35px; outline: none; cursor: pointer;"&gt;
&lt;img src="https://images.clickfunnels.com/23/a594304e4611e69c46731f5ead6411/MP-Q_A-2016061314.jpg" class="elIMG ximg"&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans%7COpen+Sans+Condensed%7COpen+Sans" id="custom_google_font"&gt;
&lt;style id="button_style_tmp_headline1-49719"&gt;#tmp_headline1-49719 .elButtonFlat:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonBottomBorder:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonSubtle:hover{background-color:#171717!important;}#tmp_headline1-49719 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(49,49,49)),color-stop(1,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 0%,#171717 100%);background-image:linear-gradient(to bottom,rgb(49,49,49) 0%,#171717 100%);}#tmp_headline1-49719 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(49,49,49)),color-stop(0,#171717));background-image:-o-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-moz-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-webkit-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:-ms-linear-gradient(bottom,rgb(49,49,49) 100%,#171717 0%);background-image:linear-gradient(to bottom,rgb(49,49,49) 100%,#171717 0%);}#tmp_headline1-49719 .elButtonBorder{border:3px solid rgb(49,49,49)!important;color:rgb(49,49,49)!important;}#tmp_headline1-49719 .elButtonBorder:hover{background-color:rgb(49,49,49)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="button_style_tmp_headline1-87137"&gt;#tmp_headline1-87137 .elButtonFlat:hover{background-color:#a30052!important;}#tmp_headline1-87137 .elButtonBottomBorder:hover{background-color:#a30052!important;}#tmp_headline1-87137 .elButtonSubtle:hover{background-color:#a30052!important;}#tmp_headline1-87137 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(204,0,102)),color-stop(1,#a30052));background-image:-o-linear-gradient(bottom,rgb(204,0,102) 0%,#a30052 100%);background-image:-moz-linear-gradient(bottom,rgb(204,0,102) 0%,#a30052 100%);background-image:-webkit-linear-gradient(bottom,rgb(204,0,102) 0%,#a30052 100%);background-image:-ms-linear-gradient(bottom,rgb(204,0,102) 0%,#a30052 100%);background-image:linear-gradient(to bottom,rgb(204,0,102) 0%,#a30052 100%);}#tmp_headline1-87137 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(204,0,102)),color-stop(0,#a30052));background-image:-o-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 0%);background-image:-moz-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 0%);background-image:-webkit-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 0%);background-image:-ms-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 0%);background-image:linear-gradient(to bottom,rgb(204,0,102) 100%,#a30052 0%);}#tmp_headline1-87137 .elButtonGradient2{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(204,0,102)),color-stop(1,#a30052));background-image:-o-linear-gradient(bottom,rgb(204,0,102) 30%,#a30052 80%);background-image:-moz-linear-gradient(bottom,rgb(204,0,102) 30%,#a30052 80%);background-image:-webkit-linear-gradient(bottom,rgb(204,0,102) 30%,#a30052 80%);background-image:-ms-linear-gradient(bottom,rgb(204,0,102) 30%,#a30052 80%);background-image:linear-gradient(to bottom,rgb(204,0,102) 30%,#a30052 80%);}#tmp_headline1-87137 .elButtonGradient2:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(204,0,102)),color-stop(0,#a30052));background-image:-o-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 30%);background-image:-moz-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 30%);background-image:-webkit-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 30%);background-image:-ms-linear-gradient(bottom,rgb(204,0,102) 100%,#a30052 30%);background-image:linear-gradient(to bottom,rgb(204,0,102) 100%,#a30052 30%);}#tmp_headline1-87137 .elButtonBorder{border:3px solid rgb(204,0,102)!important;color:rgb(204,0,102)!important;}#tmp_headline1-87137 .elButtonBorder:hover{background-color:rgb(204,0,102)!important;color:#FFF!important;}&lt;/style&gt;
&lt;style id="bullet_list_icon_color_tmp_list-35712"&gt;#tmp_list-35712 li:before{color:rgb(255,121,31)!important;}&lt;/style&gt;
</textarea>
</li>
</ul>
</div>
</li>

</ul>
</div>
<div class="de elImageWrapper de-image-block elMargin0 elAlign_center de-editable" id="tmp_image-32006" data-de-type="img" data-de-editing="false" data-title="image" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="margin-top: 10px; cursor: pointer; outline: none;">
<img src="https://images.clickfunnels.com/dd/0eb0802da511e6944e478f930b6a57/CM5-Cape-20160608.png" class="elIMG ximg" height="260">
</div>
</div>
</div>
<div id="col-right-198" class="innerContent col_right ui-resizable col-md-9" data-col="right" data-trigger="none" data-animate="fade" data-delay="500" data-title="right column" style="outline: none;">
<div class="col-inner bgCover  borderSolid cornersAll shadow0 P0-top P0-bottom P0H noTopMargin borderLight border1px radius10" style="padding: 0px 20px 20px; border-color: rgba(47, 47, 47, 0.14902); background-color: rgb(230, 230, 230);">
<div class="de clearfix elOrderProductOptionsWrapper elMargin0 de-editable" id="tmp_membercontent-70332" data-de-type="membercontent" data-de-editing="false" data-title="Membership Content" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style='cursor: pointer; outline: none; margin-top: 0px; font-family: "Open Sans", Helvetica, sans-serif !important;' data-google-font="Open+Sans">
<div class="video-description" data-cf-id="welcome-description">
<div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize2" style="text-align: left;" data-bold="inherit" contenteditable="false"><b>Example of Lesson Headline</b></div>
<div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize0" style="text-align: left; color: rgba(47, 47, 47, 0.682353);" data-bold="inherit" contenteditable="false">Lesson sub headline will be here</div>
<div class="elVideoplaceholder">
<div class="elVideoplaceholder_inner">
</div>
</div>
<div class="ne elHeadline elMargin0 elBGStyle0 hsTextShadow0 hsSize1 lh2" style="text-align: left;" data-bold="inherit" contenteditable="false">After creating this membership content template you will add lessons on the funnel overview page. Lesson content will automatically be swapped in here to create a dynamic living membership site.</div>
<div class="elDivider elDividerColor3 elDividerStyle2">
<div class="elDividerInner"></div>
</div>
<div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize1 elHeadlineIcon_none" style="text-align: left; color: rgba(47, 47, 47, 0.901961);" data-bold="inherit" contenteditable="false"><b>
Download MP4 Video</b></div>
<div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 elHeadlineIcon_none hsSize0" style="text-align: left; color: rgba(47, 47, 47, 0.772549);" data-bold="inherit" contenteditable="false">
<a href="http://google.com/" id="link-3933-343" class="" target="_self">Download Resource</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="row bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin" id="row-8923710000" data-trigger="none" data-animate="fade" data-delay="500" data-title="1 column row" style="outline: none; margin-bottom: 0px;">
<div id="col-full-300" class="col-md-12 innerContent col_left" data-col="full" data-trigger="none" data-animate="fade" data-delay="500" data-title="full column" style="outline: none;">
<div class="col-inner bgCover  noBorder borderSolid border3px cornersAll radius0 shadow0 P0-top P0-bottom P0H noTopMargin">
<div class="de elSeperator elMargin0 de-editable" id="tmp_divider-68393" data-de-type="divider" data-de-editing="false" data-title="Divider" data-ce="false" data-trigger="none" data-animate="fade" data-delay="500" style="display: block; margin-top: 10px; outline: none; cursor: pointer;">
<div class="elDivider elDividerColor3 elDividerStyle2">
<div class="elDividerInner"></div>
</div>
</div>
<div class="de elHeadlineWrapper de-editable" id="tmp_headline1-56047" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; margin-top: 20px; outline: none;">
<div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize0" style="text-align: center; color: rgba(47, 47, 47, 0.760784);" data-bold="inherit" contenteditable="false">
<b>
Questions?</b> Email us: <a class="__cf_email__" href="/cdn-cgi/l/email-protection" data-cfemail="aac2cfc6daeae9cbdadecbc3c4e7c5c4cfd3facbc4ded984c9c5c7">[email&#160;protected]</a><script data-cfhash='f9e31' type="text/javascript">/* <![CDATA[ */!function(t,e,r,n,c,a,p){try{t=document.currentScript||function(){for(t=document.getElementsByTagName('script'),e=t.length;e--;)if(t[e].getAttribute('data-cfhash'))return t[e]}();if(t&&(c=t.previousSibling)){p=t.parentNode;if(a=c.getAttribute('data-cfemail')){for(e='',r='0x'+a.substr(0,2)|0,n=2;a.length-n;n+=2)e+='%'+('0'+('0x'+a.substr(n,2)^r).toString(16)).slice(-2);p.replaceChild(document.createTextNode(decodeURIComponent(e)),c)}p.removeChild(t)}}catch(u){}}()/* ]]> */</script></div>
</div>
<div class="de elHeadlineWrapper de-editable" id="headline-24913" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; margin-top: 20px; outline: none;">
<div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize0" style="text-align: center; color: rgba(47, 47, 47, 0.760784);" data-bold="inherit" contenteditable="false">
CaptainMoneyPants.com - All Rights Reserved</div>
</div>
<div class="de elHeadlineWrapper de-editable" id="headline-98135" data-de-type="headline" data-de-editing="false" data-title="headline" data-ce="true" data-trigger="none" data-animate="fade" data-delay="500" style="cursor: pointer; margin-top: 5px; outline: none;">
<div class="ne elHeadline lh3 elMargin0 elBGStyle0 hsTextShadow0 hsSize12" style="text-align: center; color: rgba(47, 47, 47, 0.760784);" data-bold="inherit" contenteditable="false">© Rumble Productions, Inc.</div>
</div>
</div>
</div>
</div>
</div>
</div>
<style id="link_color_style">a{color:rgb(59,100,184);}</style>
<style id="button_style_tmp_membernavi-22247">#tmp_membernavi-22247 .elButtonFlat:hover{background-color:#235e84!important;}#tmp_membernavi-22247 .elButtonBottomBorder:hover{background-color:#235e84!important;}#tmp_membernavi-22247 .elButtonSubtle:hover{background-color:#235e84!important;}#tmp_membernavi-22247 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(44,117,164)),color-stop(1,#235e84));background-image:-o-linear-gradient(bottom,rgb(44,117,164) 0%,#235e84 100%);background-image:-moz-linear-gradient(bottom,rgb(44,117,164) 0%,#235e84 100%);background-image:-webkit-linear-gradient(bottom,rgb(44,117,164) 0%,#235e84 100%);background-image:-ms-linear-gradient(bottom,rgb(44,117,164) 0%,#235e84 100%);background-image:linear-gradient(to bottom,rgb(44,117,164) 0%,#235e84 100%);}#tmp_membernavi-22247 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(44,117,164)),color-stop(0,#235e84));background-image:-o-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 0%);background-image:-moz-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 0%);background-image:-webkit-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 0%);background-image:-ms-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 0%);background-image:linear-gradient(to bottom,rgb(44,117,164) 100%,#235e84 0%);}#tmp_membernavi-22247 .elButtonGradient2{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(44,117,164)),color-stop(1,#235e84));background-image:-o-linear-gradient(bottom,rgb(44,117,164) 30%,#235e84 80%);background-image:-moz-linear-gradient(bottom,rgb(44,117,164) 30%,#235e84 80%);background-image:-webkit-linear-gradient(bottom,rgb(44,117,164) 30%,#235e84 80%);background-image:-ms-linear-gradient(bottom,rgb(44,117,164) 30%,#235e84 80%);background-image:linear-gradient(to bottom,rgb(44,117,164) 30%,#235e84 80%);}#tmp_membernavi-22247 .elButtonGradient2:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(44,117,164)),color-stop(0,#235e84));background-image:-o-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 30%);background-image:-moz-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 30%);background-image:-webkit-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 30%);background-image:-ms-linear-gradient(bottom,rgb(44,117,164) 100%,#235e84 30%);background-image:linear-gradient(to bottom,rgb(44,117,164) 100%,#235e84 30%);}#tmp_membernavi-22247 .elButtonBorder{border:3px solid rgb(44,117,164)!important;color:rgb(44,117,164)!important;}#tmp_membernavi-22247 .elButtonBorder:hover{background-color:rgb(44,117,164)!important;color:#FFF!important;}</style>
<style id="button_style_tmp_headline1-33525">#tmp_headline1-33525 .elButtonFlat:hover{background-color:#ebebeb!important;}#tmp_headline1-33525 .elButtonBottomBorder:hover{background-color:#ebebeb!important;}#tmp_headline1-33525 .elButtonSubtle:hover{background-color:#ebebeb!important;}#tmp_headline1-33525 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgba(255,255,255,0)),color-stop(1,#ebebeb));background-image:-o-linear-gradient(bottom,rgba(255,255,255,0) 0%,#ebebeb 100%);background-image:-moz-linear-gradient(bottom,rgba(255,255,255,0) 0%,#ebebeb 100%);background-image:-webkit-linear-gradient(bottom,rgba(255,255,255,0) 0%,#ebebeb 100%);background-image:-ms-linear-gradient(bottom,rgba(255,255,255,0) 0%,#ebebeb 100%);background-image:linear-gradient(to bottom,rgba(255,255,255,0) 0%,#ebebeb 100%);}#tmp_headline1-33525 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgba(255,255,255,0)),color-stop(0,#ebebeb));background-image:-o-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 0%);background-image:-moz-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 0%);background-image:-webkit-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 0%);background-image:-ms-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 0%);background-image:linear-gradient(to bottom,rgba(255,255,255,0) 100%,#ebebeb 0%);}#tmp_headline1-33525 .elButtonGradient2{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgba(255,255,255,0)),color-stop(1,#ebebeb));background-image:-o-linear-gradient(bottom,rgba(255,255,255,0) 30%,#ebebeb 80%);background-image:-moz-linear-gradient(bottom,rgba(255,255,255,0) 30%,#ebebeb 80%);background-image:-webkit-linear-gradient(bottom,rgba(255,255,255,0) 30%,#ebebeb 80%);background-image:-ms-linear-gradient(bottom,rgba(255,255,255,0) 30%,#ebebeb 80%);background-image:linear-gradient(to bottom,rgba(255,255,255,0) 30%,#ebebeb 80%);}#tmp_headline1-33525 .elButtonGradient2:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgba(255,255,255,0)),color-stop(0,#ebebeb));background-image:-o-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 30%);background-image:-moz-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 30%);background-image:-webkit-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 30%);background-image:-ms-linear-gradient(bottom,rgba(255,255,255,0) 100%,#ebebeb 30%);background-image:linear-gradient(to bottom,rgba(255,255,255,0) 100%,#ebebeb 30%);}#tmp_headline1-33525 .elButtonBorder{border:3px solid rgba(255,255,255,0)!important;color:rgba(255,255,255,0)!important;}#tmp_headline1-33525 .elButtonBorder:hover{background-color:rgba(255,255,255,0)!important;color:#000!important;}</style>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Droid+Serif%7COpen+Sans%7CDroid+Serif%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans%7COpen+Sans" id="custom_google_font" google-font="Open+Sans">
<style id="bold_style_tmp_headline1-73685">#tmp_headline1-73685 .elHeadline b{color:rgb(255,255,255);}</style>
<style id="button_style_tmp_membernavi-34678">#tmp_membernavi-34678 .elButtonFlat:hover{background-color:#565c64!important;}#tmp_membernavi-34678 .elButtonBottomBorder:hover{background-color:#565c64!important;}#tmp_membernavi-34678 .elButtonSubtle:hover{background-color:#565c64!important;}#tmp_membernavi-34678 .elButtonGradient{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,rgb(110,117,127)),color-stop(1,#565c64));background-image:-o-linear-gradient(bottom,rgb(110,117,127) 0%,#565c64 100%);background-image:-moz-linear-gradient(bottom,rgb(110,117,127) 0%,#565c64 100%);background-image:-webkit-linear-gradient(bottom,rgb(110,117,127) 0%,#565c64 100%);background-image:-ms-linear-gradient(bottom,rgb(110,117,127) 0%,#565c64 100%);background-image:linear-gradient(to bottom,rgb(110,117,127) 0%,#565c64 100%);}#tmp_membernavi-34678 .elButtonGradient:hover{background-image:-webkit-gradient(linear,left top,left bottom,color-stop(1,rgb(110,117,127)),color-stop(0,#565c64));background-image:-o-linear-gradient(bottom,rgb(110,117,127) 100%,#565c64 0%);background-image:-moz-linear-gradient(bottom,rgb(110,117,127) 100%,#565c64 0%);background-image:-webkit-linear-gradient(bottom,rgb(110,117,127) 100%,#565c64 0%);background-image:-ms-linear-gradient(bottom,rgb(110,117,127) 100%,#565c64 0%);background-image:linear-gradient(to bottom,rgb(110,117,127) 100%,#565c64 0%);}#tmp_membernavi-34678 .elButtonBorder{border:3px solid rgb(110,117,127)!important;color:rgb(110,117,127)!important;}#tmp_membernavi-34678 .elButtonBorder:hover{background-color:rgb(110,117,127)!important;color:#FFF!important;}</style>
<style id="bold_style_tmp_headline1-67102">#tmp_headline1-67102 .elHeadline b{color:rgb(47,47,47);}</style>

  </div>
  <style id="custom-css"></style>
  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&appId=246441615530259&version=v2.0";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>
  <input type="hidden" value="9228138" id="page-id">
  <input type="hidden" value="9228138" id="root-id">
  <input type="hidden" value="core" id="variant-check">
  <input type="hidden" value="842672" id="user-id">

  <script src="https://appassets.clickfunnels.com/assets/lander.js"></script>

<!--[if lt IE 9]>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7/html5shiv.min.js"></script>
<![endif]-->
  <form target="_parent" data-cf-form-action="true" action="https://captainmoneypants.com/membership-area/abff71bae4c" method="post" id="cfAR" style="display:none">
    <span data-cf-form-fields="true"></span>
    <input id="cf_contact_name" name="contact[name]" data-cf-form-field="name" placeholder="name" data-stripe="name">
    <input id="cf_contact_first_name" name="contact[first_name]" data-cf-form-field="first_name" placeholder="first_name" data-recurly="first_name">
    <input id="cf_contact_last_name" name="contact[last_name]" data-cf-form-field="last_name" placeholder="last_name" data-recurly="last_name">
    <input id="cf_contact_email" name="contact[email]" data-cf-form-field="email" placeholder="email">
    <input id="cf_contact_phone" name="contact[phone]" data-cf-form-field="phone" placeholder="phone" data-recurly="phone">
    <input id="cf_contact_address" name="contact[address]" data-cf-form-field="address" placeholder="address" data-stripe="address_line1" data-recurly="address1">
    <input id="cf_contact_city" name="contact[city]" data-cf-form-field="city" placeholder="city" data-stripe="address_city" data-recurly="city">
    <input id="cf_contact_state" name="contact[state]" data-cf-form-field="state" placeholder="state" data-stripe="address_state" data-recurly="state">
    <input id="cf_contact_country" name="contact[country]" data-cf-form-field="country" placeholder="country" data-stripe="address_country" data-recurly="country">
    <input id="cf_contact_zip" name="contact[zip]" data-cf-form-field="zip" placeholder="ZIP" data-stripe="address_zip" data-recurly="postal_code">
    <input id="cf_contact_shipping_address" name="contact[shipping_address]" data-cf-form-field="shipping_address" placeholder="shipping_address" data-stripe="shipping_address">
    <input id="cf_contact_shipping_city" name="contact[shipping_city]" data-cf-form-field="shipping_city" placeholder="shipping_city" data-stripe="shipping_city">
    <input id="cf_contact_shipping_state" name="contact[shipping_state]" data-cf-form-field="shipping_state" placeholder="shipping_state" data-stripe="shipping_state">
    <input id="cf_contact_shipping_country" name="contact[shipping_country]" data-cf-form-field="shipping_country" placeholder="shipping_country" data-stripe="shipping_country">
    <input id="cf_contact_shipping_zip" name="contact[shipping_zip]" data-cf-form-field="shipping_zip" placeholder="shipping_ZIP" data-stripe="shipping_zip">
    <input id="cf_contact_vat_number" name="contact[vat_number]" data-cf-form-field="vat_number" data-recurly="vat_number">
    <input id="cf_contact_affiliate_id" name="contact[affiliate_id]" data-cf-form-field="affiliate_id" data-param="affiliate_id">
    <input id="cf_contact_cf_affiliate_id" name="contact[cf_affiliate_id]" data-cf-form-field="cf_affiliate_id" data-param="cf_affiliate_id">
    <input id="cf_cf_affiliate_id" name="cf_affiliate_id" data-param="cf_affiliate_id">
    <input id="cf_contact_affiliate_aff_sub" name="contact[aff_sub]" data-cf-form-field="aff_sub" data-param="aff_sub">
    <input id="cf_contact_affiliate_aff_sub2" name="contact[aff_sub2]" data-cf-form-field="aff_sub2" data-param="aff_sub2">
    <input id="utm_source" name="utm_source" data-cf-form-field="utm_source" data-param="utm_source">
    <input id="utm_medium" name="utm_medium" data-cf-form-field="utm_medium" data-param="utm_medium">
    <input id="utm_campaign" name="utm_campaign" data-cf-form-field="utm_campaign" data-param="utm_campaign">
    <input id="utm_term" name="utm_term" data-cf-form-field="utm_term" data-param="utm_term">
    <input id="utm_content" name="utm_content" data-cf-form-field="utm_content" data-param="utm_content">
    <input type="text" name="webinar_delay" id="webinar_delay" placeholder="Webinar Delay">
    <span data-cf-product-template="true">
      <input type="radio" name="purchase[product_id]" value="" data-storage="false">
      <input type="checkbox" name="purchase[product_ids][]" value="" data-storage="false">
    </span>
    <input name="purchase[taxamo_transaction_key]" data-storage="false">
    <input id="cf_contact_number" data-stripe="number" data-storage="false" data-recurly="number">
    <input id="cf_contact_month" data-stripe="exp-month" data-storage="" data-recurly="month">
    <input id="cf_contact_year" data-stripe="exp-year" data-storage="" data-recurly="year">
    <input id="cf_contact_cvc" data-stripe="cvc" data-storage="false" data-recurly="cvv">
    <input type="hidden" name="purchase[payment_method_nonce]" data-storage="false">

    <input type="submit">
  <input name="contact[cart_affiliate_id]" value="" type="hidden" style="display:none;" data-param="affiliate">
</form>
  <span class="countdown-time" style="display:none;"></span>
  <span class="webinar-last-time" style="display:none;"></span>
  <span class="webinar-ext" style="display:none;">T2JM7RhM</span>
  <span class="webinar-ot" style="display:none;">0.0</span>
  <div class="otoloading" style="display: none;">
    <div class="otoloadingtext">
      <h2>Working...</h2>
      <div><i class="fa fa-spinner fa-spin"></i></div>
    </div>
  </div>
  <script type="text/javascript">
    document.createElement('video');document.createElement('audio');document.createElement('track');
  </script>
  <style>
    #IntercomDefaultWidget{display:none}.selectAW-date-demo,.elTicketAddToCalendar{display:none}.video-js{padding-top:56.25%}.vjs-fullscreen{padding-top:0}
  </style>


<script type="text/html" id="cfx_all_canada">
    <option value="AB">Alberta</option>
    <option value="BC">British Columbia</option>
    <option value="MB">Manitoba</option>
    <option value="NB">New Brunswick</option>
    <option value="NL">Newfoundland and Labrador</option>
    <option value="NS">Nova Scotia</option>
    <option value="ON">Ontario</option>
    <option value="PE">Prince Edward Island</option>
    <option value="QC">Quebec</option>
    <option value="SK">Saskatchewan</option>
    <option value="NT">Northwest Territories</option>
    <option value="NU">Nunavut</option>
    <option value="YT">Yukon</option>
</script>

<script type="text/html" id="cfx_all_states">
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District Of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>
</script>

<script type="text/html" id="cfx_all_countries">
    <option value="">Select Country</option>
    <option value="">------------------------------</option>
    <option value="United States of America">United States</option>
    <option value="Canada">Canada</option>
    <option value="United Kingdom">United Kingdom</option>
    <option value="Ireland">Ireland</option>
    <option value="Australia">Australia</option>
    <option value="New Zealand">New Zealand</option>
    <option value="">------------------------------</option>
    <option value="Afghanistan">Afghanistan</option>
    <option value="Albania">Albania</option>
    <option value="Algeria">Algeria</option>
    <option value="American Samoa">American Samoa</option>
    <option value="Andorra">Andorra</option>
    <option value="Angola">Angola</option>
    <option value="Anguilla">Anguilla</option>
    <option value="Antarctica">Antarctica</option>
    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
    <option value="Argentina">Argentina</option>
    <option value="Armenia">Armenia</option>
    <option value="Aruba">Aruba</option>
    <option value="Australia">Australia</option>
    <option value="Austria">Austria</option>
    <option value="Azerbaijan">Azerbaijan</option>
    <option value="Bahamas">Bahamas</option>
    <option value="Bahrain">Bahrain</option>
    <option value="Bangladesh">Bangladesh</option>
    <option value="Barbados">Barbados</option>
    <option value="Belarus">Belarus</option>
    <option value="Belgium">Belgium</option>
    <option value="Belize">Belize</option>
    <option value="Benin">Benin</option>
    <option value="Bermuda">Bermuda</option>
    <option value="Bhutan">Bhutan</option>
    <option value="Bolivia">Bolivia</option>
    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
    <option value="Botswana">Botswana</option>
    <option value="Bouvet Island">Bouvet Island</option>
    <option value="Brazil">Brazil</option>
    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
    <option value="Brunei Darussalam">Brunei Darussalam</option>
    <option value="Bulgaria">Bulgaria</option>
    <option value="Burkina Faso">Burkina Faso</option>
    <option value="Burundi">Burundi</option>
    <option value="Cambodia">Cambodia</option>
    <option value="Cameroon">Cameroon</option>
    <option value="Canada">Canada</option>
    <option value="Cape Verde">Cape Verde</option>
    <option value="Cayman Islands">Cayman Islands</option>
    <option value="Central African Republic">Central African Republic</option>
    <option value="Chad">Chad</option>
    <option value="Chile">Chile</option>
    <option value="China">China</option>
    <option value="Christmas Island">Christmas Island</option>
    <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
    <option value="Colombia">Colombia</option>
    <option value="Comoros">Comoros</option>
    <option value="Congo">Congo</option>
    <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
    <option value="Cook Islands">Cook Islands</option>
    <option value="Costa Rica">Costa Rica</option>
    <option value="Cote D'ivoire">Cote D'ivoire</option>
    <option value="Croatia">Croatia</option>
    <option value="Cuba">Cuba</option>
    <option value="Cyprus">Cyprus</option>
    <option value="Czech Republic">Czech Republic</option>
    <option value="Denmark">Denmark</option>
    <option value="Djibouti">Djibouti</option>
    <option value="Dominica">Dominica</option>
    <option value="Dominican Republic">Dominican Republic</option>
    <option value="Ecuador">Ecuador</option>
    <option value="Egypt">Egypt</option>
    <option value="El Salvador">El Salvador</option>
    <option value="Equatorial Guinea">Equatorial Guinea</option>
    <option value="Eritrea">Eritrea</option>
    <option value="Estonia">Estonia</option>
    <option value="Ethiopia">Ethiopia</option>
    <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
    <option value="Faroe Islands">Faroe Islands</option>
    <option value="Fiji">Fiji</option>
    <option value="Finland">Finland</option>
    <option value="France">France</option>
    <option value="French Guiana">French Guiana</option>
    <option value="French Polynesia">French Polynesia</option>
    <option value="French Southern Territories">French Southern Territories</option>
    <option value="Gabon">Gabon</option>
    <option value="Gambia">Gambia</option>
    <option value="Georgia">Georgia</option>
    <option value="Germany">Germany</option>
    <option value="Ghana">Ghana</option>
    <option value="Gibraltar">Gibraltar</option>
    <option value="Greece">Greece</option>
    <option value="Greenland">Greenland</option>
    <option value="Grenada">Grenada</option>
    <option value="Guadeloupe">Guadeloupe</option>
    <option value="Guam">Guam</option>
    <option value="Guatemala">Guatemala</option>
    <option value="Guinea">Guinea</option>
    <option value="Guinea-bissau">Guinea-bissau</option>
    <option value="Guyana">Guyana</option>
    <option value="Haiti">Haiti</option>
    <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
    <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
    <option value="Honduras">Honduras</option>
    <option value="Hong Kong">Hong Kong</option>
    <option value="Hungary">Hungary</option>
    <option value="Iceland">Iceland</option>
    <option value="India">India</option>
    <option value="Indonesia">Indonesia</option>
    <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
    <option value="Iraq">Iraq</option>
    <option value="Ireland">Ireland</option>
    <option value="Israel">Israel</option>
    <option value="Italy">Italy</option>
    <option value="Jamaica">Jamaica</option>
    <option value="Japan">Japan</option>
    <option value="Jordan">Jordan</option>
    <option value="Kazakhstan">Kazakhstan</option>
    <option value="Kenya">Kenya</option>
    <option value="Kiribati">Kiribati</option>
    <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
    <option value="Korea, Republic of">Korea, Republic of</option>
    <option value="Kuwait">Kuwait</option>
    <option value="Kyrgyzstan">Kyrgyzstan</option>
    <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
    <option value="Latvia">Latvia</option>
    <option value="Lebanon">Lebanon</option>
    <option value="Lesotho">Lesotho</option>
    <option value="Liberia">Liberia</option>
    <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
    <option value="Liechtenstein">Liechtenstein</option>
    <option value="Lithuania">Lithuania</option>
    <option value="Luxembourg">Luxembourg</option>
    <option value="Macao">Macao</option>
    <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
    <option value="Madagascar">Madagascar</option>
    <option value="Malawi">Malawi</option>
    <option value="Malaysia">Malaysia</option>
    <option value="Maldives">Maldives</option>
    <option value="Mali">Mali</option>
    <option value="Malta">Malta</option>
    <option value="Marshall Islands">Marshall Islands</option>
    <option value="Martinique">Martinique</option>
    <option value="Mauritania">Mauritania</option>
    <option value="Mauritius">Mauritius</option>
    <option value="Mayotte">Mayotte</option>
    <option value="Mexico">Mexico</option>
    <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
    <option value="Moldova, Republic of">Moldova, Republic of</option>
    <option value="Monaco">Monaco</option>
    <option value="Mongolia">Mongolia</option>
    <option value="Montserrat">Montserrat</option>
    <option value="Morocco">Morocco</option>
    <option value="Mozambique">Mozambique</option>
    <option value="Myanmar">Myanmar</option>
    <option value="Namibia">Namibia</option>
    <option value="Nauru">Nauru</option>
    <option value="Nepal">Nepal</option>
    <option value="Netherlands">Netherlands</option>
    <option value="Netherlands Antilles">Netherlands Antilles</option>
    <option value="New Caledonia">New Caledonia</option>
    <option value="New Zealand">New Zealand</option>
    <option value="Nicaragua">Nicaragua</option>
    <option value="Niger">Niger</option>
    <option value="Nigeria">Nigeria</option>
    <option value="Niue">Niue</option>
    <option value="Norfolk Island">Norfolk Island</option>
    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
    <option value="Norway">Norway</option>
    <option value="Oman">Oman</option>
    <option value="Pakistan">Pakistan</option>
    <option value="Palau">Palau</option>
    <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
    <option value="Panama">Panama</option>
    <option value="Papua New Guinea">Papua New Guinea</option>
    <option value="Paraguay">Paraguay</option>
    <option value="Peru">Peru</option>
    <option value="Philippines">Philippines</option>
    <option value="Pitcairn">Pitcairn</option>
    <option value="Poland">Poland</option>
    <option value="Portugal">Portugal</option>
    <option value="Puerto Rico">Puerto Rico</option>
    <option value="Qatar">Qatar</option>
    <option value="Reunion">Reunion</option>
    <option value="Romania">Romania</option>
    <option value="Russian Federation">Russian Federation</option>
    <option value="Rwanda">Rwanda</option>
    <option value="Saint Helena">Saint Helena</option>
    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
    <option value="Saint Lucia">Saint Lucia</option>
    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
    <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
    <option value="Samoa">Samoa</option>
    <option value="San Marino">San Marino</option>
    <option value="Sao Tome and Principe">Sao Tome and Principe</option>
    <option value="Saudi Arabia">Saudi Arabia</option>
    <option value="Senegal">Senegal</option>
    <option value="Serbia and Montenegro">Serbia and Montenegro</option>
    <option value="Seychelles">Seychelles</option>
    <option value="Sierra Leone">Sierra Leone</option>
    <option value="Singapore">Singapore</option>
    <option value="Slovakia">Slovakia</option>
    <option value="Slovenia">Slovenia</option>
    <option value="Solomon Islands">Solomon Islands</option>
    <option value="Somalia">Somalia</option>
    <option value="South Africa">South Africa</option>
    <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
    <option value="Spain">Spain</option>
    <option value="Sri Lanka">Sri Lanka</option>
    <option value="Sudan">Sudan</option>
    <option value="Suriname">Suriname</option>
    <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
    <option value="Swaziland">Swaziland</option>
    <option value="Sweden">Sweden</option>
    <option value="Switzerland">Switzerland</option>
    <option value="Syrian Arab Republic">Syrian Arab Republic</option>
    <option value="Taiwan, Province of China">Taiwan, Province of China</option>
    <option value="Tajikistan">Tajikistan</option>
    <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
    <option value="Thailand">Thailand</option>
    <option value="Timor-leste">Timor-leste</option>
    <option value="Togo">Togo</option>
    <option value="Tokelau">Tokelau</option>
    <option value="Tonga">Tonga</option>
    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
    <option value="Tunisia">Tunisia</option>
    <option value="Turkey">Turkey</option>
    <option value="Turkmenistan">Turkmenistan</option>
    <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
    <option value="Tuvalu">Tuvalu</option>
    <option value="Uganda">Uganda</option>
    <option value="Ukraine">Ukraine</option>
    <option value="United Arab Emirates">United Arab Emirates</option>
    <option value="United Kingdom">United Kingdom</option>
    <option value="United States">United States</option>
    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
    <option value="Uruguay">Uruguay</option>
    <option value="Uzbekistan">Uzbekistan</option>
    <option value="Vanuatu">Vanuatu</option>
    <option value="Venezuela">Venezuela</option>
    <option value="Viet Nam">Viet Nam</option>
    <option value="Virgin Islands, British">Virgin Islands, British</option>
    <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
    <option value="Wallis and Futuna">Wallis and Futuna</option>
    <option value="Western Sahara">Western Sahara</option>
    <option value="Yemen">Yemen</option>
    <option value="Zambia">Zambia</option>
    <option value="Zimbabwe">Zimbabwe</option>
</script>


    <script>
      var page_key = 'w263r7dlhdgktbt2';
      var fid = '2784647';
      var fspos = '2';
      var fvrs = '1';
      var cf_tracker = cf_tracker || [];
      (function() {
        cf_key = '4wz3zdlh';
        page_key = 'w263r7dlhdgktbt2';
        serverUrl = 'https://app.clickfunnels.com/v1/track';
        var cf = document.createElement('script');
        cf.type = 'text/javascript';
        cf.async = true;
        cf.src = 'https://app.clickfunnels.com/cf.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(cf, s);
      })();
    </script>
<script type="text/javascript">function getURLParameter(e){return decodeURIComponent((RegExp(e+"=(.+?)(&|$)").exec(location.search)||[,null])[1])}</script><script type="text/javascript">$(function(){"null"!=getURLParameter("email")&&($('input[name="contact[email]"]').val(getURLParameter("email")),$("[name=email]").val(getURLParameter("email"))),"null"!=getURLParameter("name")&&($('input[name="contact[name]"]').val(getURLParameter("name")),$("[name=name]").val(getURLParameter("name"))),"null"!=getURLParameter("first_name")&&($('input[name="contact[first_name]"]').val(getURLParameter("first_name")),$("[name=first_name]").val(getURLParameter("first_name"))),"null"!=getURLParameter("last_name")&&($('input[name="contact[last_name]"]').val(getURLParameter("last_name")),$("[name=last_name]").val(getURLParameter("last_name"))),"null"!=getURLParameter("address_1")&&($('input[name="contact[address_1]"]').val(getURLParameter("address")),$("[name=address_1]").val(getURLParameter("address_1"))),"null"!=getURLParameter("address_2")&&($('input[name="contact[address_1]"]').val(getURLParameter("address")),$("[name=address_2]").val(getURLParameter("address_2"))),"null"!=getURLParameter("city")&&($('input[name="contact[city]"]').val(getURLParameter("city")),$("[name=city]").val(getURLParameter("city"))),"null"!=getURLParameter("state")&&($('input[name="contact[state]"]').val(getURLParameter("state")),$("[name=state]").val(getURLParameter("state"))),"null"!=getURLParameter("zip")&&($('input[name="contact[zip]"]').val(getURLParameter("zip")),$("[name=zip]").val(getURLParameter("zip"))),"null"!=getURLParameter("phone")&&($('input[name="contact[phone]"]').val(getURLParameter("phone")),$("[name=phone]").val(getURLParameter("phone")))});</script>
</body>
</html>


